package com.example

import com.example.engine.DnsLookupStatus
import com.example.engine.DomainAnalyzer
import com.example.engine.IpAnalyzer
import com.example.engine.IpVersion
import com.example.engine.PasswordAnalyzer
import com.example.engine.SecurityHeadersAnalyzer
import com.example.engine.StrengthTier
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CyberForgeAnalyzersTest {

    @Test
    fun passwordAnalyzerFlagsWeakPatternsAndScoresGeneratedStrong() {
        val weak = PasswordAnalyzer.analyze("password1234")
        assertTrue(weak.tier == StrengthTier.CRITICAL || weak.tier == StrengthTier.WEAK)
        assertTrue(weak.findings.any { it.title.contains("Dictionary") })
        assertTrue(weak.findings.any { it.title.contains("Sequential") })

        val generated = PasswordAnalyzer.generateStrongPassword(18)
        val strong = PasswordAnalyzer.analyze(generated)
        assertEquals(18, strong.length)
        assertTrue(strong.tier == StrengthTier.STRONG || strong.tier == StrengthTier.FORTIFIED)
    }

    @Test
    fun domainAnalyzerValidatesSyntaxAndRespectsOfflineMode() = runTest {
        val invalid = DomainAnalyzer.analyze("not valid host", liveNetworkEnabled = false, timeoutSeconds = 5)
        assertTrue(invalid.isFailure)

        val valid = DomainAnalyzer.analyze(
            rawInput = "https://api.staging.example.com:8443/v1/health",
            liveNetworkEnabled = false,
            timeoutSeconds = 5,
        )
        assertTrue(valid.isSuccess)
        val data = valid.getOrThrow()
        assertEquals("api.staging.example.com", data.hostname)
        assertEquals("example.com", data.rootDomain)
        assertEquals(listOf("api", "staging"), data.subdomainLabels)
        assertEquals(8443, data.port)
        assertEquals(DnsLookupStatus.DISABLED_OFFLINE_MODE, data.dnsResult.status)
    }

    @Test
    fun ipAnalyzerValidatesAndClassifiesIpv4AndIpv6() {
        val priv = IpAnalyzer.analyze("192.168.10.25").getOrThrow()
        assertEquals(IpVersion.IPV4, priv.version)
        assertTrue(priv.classification.contains("RFC 1918"))

        val ssrf = IpAnalyzer.analyze("169.254.169.254").getOrThrow()
        assertTrue(ssrf.classification.contains("Link-Local"))

        val v6Doc = IpAnalyzer.analyze("2001:db8::1").getOrThrow()
        assertEquals(IpVersion.IPV6, v6Doc.version)
        assertTrue(v6Doc.classification.contains("Documentation"))

        val bad = IpAnalyzer.analyze("999.168.1.1")
        assertFalse(bad.isSuccess)
    }

    @Test
    fun securityHeadersAnalyzerRejectsOfflineFetchWithoutFabricating() = runTest {
        val res = SecurityHeadersAnalyzer.inspect(
            rawUrl = "https://example.com",
            liveNetworkEnabled = false,
            timeoutSeconds = 5,
        )
        assertTrue(res.isFailure)
        assertTrue(res.exceptionOrNull()?.message?.contains("Offline") == true)
    }
}
