package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.cyberForgeDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "cyberforge_prefs",
)

class SettingsPreferencesRepository(private val context: Context) {

    private object Keys {
        val ACCENT_THEME = stringPreferencesKey("accent_theme")
        val LIVE_NETWORK_ENABLED = booleanPreferencesKey("live_network_enabled")
        val TIMEOUT_SECONDS = intPreferencesKey("timeout_seconds")
        val SHOW_TERMINAL_GRID = booleanPreferencesKey("show_terminal_grid")
        val HIGH_CONTRAST_BORDERS = booleanPreferencesKey("high_contrast_borders")
        val ACTIVITY_LOG = stringPreferencesKey("activity_log_v1")
    }

    val scanConfigFlow: Flow<ScanConfig> = context.cyberForgeDataStore.data.map { prefs ->
        val themeName = prefs[Keys.ACCENT_THEME] ?: AccentTheme.CYBER_MATRIX.name
        val accentTheme = runCatching { AccentTheme.valueOf(themeName) }
            .getOrDefault(AccentTheme.CYBER_MATRIX)
        ScanConfig(
            liveNetworkEnabled = prefs[Keys.LIVE_NETWORK_ENABLED] ?: true,
            timeoutSeconds = (prefs[Keys.TIMEOUT_SECONDS] ?: 8).coerceIn(3, 20),
            showTerminalGrid = prefs[Keys.SHOW_TERMINAL_GRID] ?: true,
            highContrastBorders = prefs[Keys.HIGH_CONTRAST_BORDERS] ?: false,
            accentTheme = accentTheme,
        )
    }

    val activityLogFlow: Flow<List<ActivityLogEntry>> = context.cyberForgeDataStore.data.map { prefs ->
        decodeHistory(prefs[Keys.ACTIVITY_LOG].orEmpty())
    }

    suspend fun updateAccentTheme(theme: AccentTheme) {
        context.cyberForgeDataStore.edit { it[Keys.ACCENT_THEME] = theme.name }
    }

    suspend fun updateLiveNetworkEnabled(enabled: Boolean) {
        context.cyberForgeDataStore.edit { it[Keys.LIVE_NETWORK_ENABLED] = enabled }
    }

    suspend fun updateTimeoutSeconds(seconds: Int) {
        context.cyberForgeDataStore.edit { it[Keys.TIMEOUT_SECONDS] = seconds.coerceIn(3, 20) }
    }

    suspend fun updateShowTerminalGrid(show: Boolean) {
        context.cyberForgeDataStore.edit { it[Keys.SHOW_TERMINAL_GRID] = show }
    }

    suspend fun updateHighContrastBorders(enabled: Boolean) {
        context.cyberForgeDataStore.edit { it[Keys.HIGH_CONTRAST_BORDERS] = enabled }
    }

    suspend fun appendActivity(entry: ActivityLogEntry) {
        context.cyberForgeDataStore.edit { prefs ->
            val current = decodeHistory(prefs[Keys.ACTIVITY_LOG].orEmpty())
            val updated = (listOf(entry) + current).take(25)
            prefs[Keys.ACTIVITY_LOG] = encodeHistory(updated)
        }
    }

    suspend fun clearActivityHistory() {
        context.cyberForgeDataStore.edit { prefs ->
            prefs.remove(Keys.ACTIVITY_LOG)
        }
    }

    private fun encodeHistory(entries: List<ActivityLogEntry>): String {
        return entries.joinToString("\n") { e ->
            val safeSummary = e.summary.replace("|", "/").replace("\n", " ")
            val safeDetail = e.detail.replace("|", "/").replace("\n", " ")
            "${e.id}|${e.tool.name}|$safeSummary|$safeDetail|${e.status.name}|${e.timestampMillis}"
        }
    }

    private fun decodeHistory(raw: String): List<ActivityLogEntry> {
        if (raw.isBlank()) return emptyList()
        return raw.lines().mapNotNull { line ->
            val parts = line.split("|")
            if (parts.size < 6) return@mapNotNull null
            runCatching {
                ActivityLogEntry(
                    id = parts[0].toLong(),
                    tool = ToolCategory.valueOf(parts[1]),
                    summary = parts[2],
                    detail = parts[3],
                    status = ActivityStatus.valueOf(parts[4]),
                    timestampMillis = parts[5].toLong(),
                )
            }.getOrNull()
        }
    }
}
