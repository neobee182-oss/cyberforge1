package com.example.engine

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

enum class IpVersion(val label: String) {
    IPV4("IPv4 (32-bit)"),
    IPV6("IPv6 (128-bit)"),
}

data class IpAnalysisResult(
    val input: String,
    val canonicalAddress: String,
    val version: IpVersion,
    val classification: String,
    val routingScope: String,
    val rfcReference: String,
    val binaryOrHexRepresentation: String,
    val subnetExample: String,
    val educationalNotes: List<String>,
)

object IpAnalyzer {

    private val ipv4Segment = "(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)"
    private val ipv4Regex = Regex("^$ipv4Segment\\.$ipv4Segment\\.$ipv4Segment\\.$ipv4Segment$")

    fun isValidIp(input: String): Boolean {
        val clean = input.trim().substringBefore("%")
        return ipv4Regex.matches(clean) || isValidIpv6Syntax(clean)
    }

    fun analyze(rawInput: String): Result<IpAnalysisResult> {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter an IPv4 (e.g. 192.168.1.1) or IPv6 (e.g. 2001:db8::1) address."))
        }

        val zonePart = trimmed.substringAfter("%", missingDelimiterValue = "")
        val ipOnly = trimmed.substringBefore("%")

        if (ipv4Regex.matches(ipOnly)) {
            val bytes = ipOnly.split(".").map { it.toInt() }
            val addr = InetAddress.getByAddress(bytes.map { it.toByte() }.toByteArray()) as Inet4Address
            val binary = bytes.joinToString(".") { it.toString(2).padStart(8, '0') }
            val (classification, scope, rfc, notes) = classifyIpv4(bytes)

            return Result.success(
                IpAnalysisResult(
                    input = trimmed,
                    canonicalAddress = addr.hostAddress ?: ipOnly,
                    version = IpVersion.IPV4,
                    classification = classification,
                    routingScope = scope,
                    rfcReference = rfc,
                    binaryOrHexRepresentation = binary,
                    subnetExample = "${bytes[0]}.${bytes[1]}.${bytes[2]}.0/24 (254 usable hosts)",
                    educationalNotes = notes,
                ),
            )
        }

        if (isValidIpv6Syntax(ipOnly)) {
            val parsed = try {
                InetAddress.getByName(ipOnly) as? Inet6Address
            } catch (_: Exception) {
                null
            } ?: return Result.failure(IllegalArgumentException("Invalid IPv6 address formatting."))

            val rawBytes = parsed.address
            val hextets = (0 until 16 step 2).map { idx ->
                val hi = rawBytes[idx].toInt() and 0xFF
                val lo = rawBytes[idx + 1].toInt() and 0xFF
                ((hi shl 8) or lo).toString(16).padStart(4, '0')
            }
            val expanded = hextets.joinToString(":")
            val (classification, scope, rfc, notes) = classifyIpv6(rawBytes, zonePart)

            return Result.success(
                IpAnalysisResult(
                    input = trimmed,
                    canonicalAddress = parsed.hostAddress?.substringBefore("%") ?: expanded,
                    version = IpVersion.IPV6,
                    classification = classification,
                    routingScope = scope,
                    rfcReference = rfc,
                    binaryOrHexRepresentation = expanded,
                    subnetExample = "${hextets.take(4).joinToString(":")}::/64 (standard LAN prefix)",
                    educationalNotes = notes,
                ),
            )
        }

        return Result.failure(
            IllegalArgumentException("'$trimmed' is not a valid IPv4 or IPv6 address. Check octets (0–255) or IPv6 hex groups."),
        )
    }

    private fun isValidIpv6Syntax(candidate: String): Boolean {
        if (!candidate.contains(":")) return false
        if (candidate.count { it == ':' } < 2 || candidate.count { it == ':' } > 7) {
            if (!candidate.contains("::")) return false
        }
        // Reject multiple '::' compressions
        if (candidate.indexOf("::") != candidate.lastIndexOf("::")) return false
        // Must only contain hex digits, colons, or dots (for IPv4-mapped)
        if (!candidate.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' || it == ':' || it == '.' }) {
            return false
        }
        return try {
            val addr = InetAddress.getByName(candidate)
            addr is Inet6Address
        } catch (_: Exception) {
            false
        }
    }

    private data class ClassificationInfo(
        val classification: String,
        val scope: String,
        val rfc: String,
        val notes: List<String>,
    )

    private fun classifyIpv4(octets: List<Int>): ClassificationInfo {
        val (a, b, c, _) = octets
        return when {
            a == 0 -> ClassificationInfo(
                "Current Network ('This' Network)",
                "Non-Routable (Host/Source Only)",
                "RFC 1122",
                listOf(
                    "0.0.0.0/8 refers to the current network or unspecified listening socket.",
                    "In servers, binding to 0.0.0.0 listens on all local IPv4 interfaces.",
                ),
            )
            a == 127 -> ClassificationInfo(
                "Loopback Address",
                "Host-Local Only",
                "RFC 1122",
                listOf(
                    "Traffic to 127.0.0.0/8 stays inside the device network stack and never hits a physical NIC.",
                    "127.0.0.1 (localhost) is commonly used for local development and internal IPC.",
                ),
            )
            a == 10 || (a == 172 && b in 16..31) || (a == 192 && b == 168) -> ClassificationInfo(
                "Private Network (RFC 1918)",
                "Internal LAN / Non-Routable on Public Internet",
                "RFC 1918",
                listOf(
                    "Private ranges: 10.0.0.0/8, 172.16.0.0/12, and 192.168.0.0/16.",
                    "Devices inside private networks reach the public internet via NAT (Network Address Translation).",
                ),
            )
            a == 100 && b in 64..127 -> ClassificationInfo(
                "Shared Address Space (CGNAT)",
                "ISP Carrier-Grade NAT",
                "RFC 6598",
                listOf(
                    "100.64.0.0/10 is reserved for ISP Carrier-Grade NAT to conserve IPv4 addresses.",
                    "Also used by some overlay VPN meshes like Tailscale.",
                ),
            )
            a == 169 && b == 254 -> ClassificationInfo(
                "Link-Local (APIPA)",
                "Single Link / No Gateway",
                "RFC 3927",
                listOf(
                    "Assigned automatically when DHCP fails on a local network segment.",
                    "169.254.169.254 is famously used by cloud providers for instance metadata endpoints (protect against SSRF!).",
                ),
            )
            (a == 192 && b == 0 && c == 2) || (a == 198 && b == 51 && c == 100) || (a == 203 && b == 0 && c == 113) -> ClassificationInfo(
                "Documentation / Example Range",
                "Non-Routable (Reserved for Docs)",
                "RFC 5737",
                listOf(
                    "TEST-NET-1, TEST-NET-2, and TEST-NET-3 are safe for tutorials, diagrams, and unit tests.",
                ),
            )
            a in 224..239 -> ClassificationInfo(
                "IPv4 Multicast",
                "Group Multicast Distribution",
                "RFC 5771",
                listOf(
                    "224.0.0.0/4 delivers packets to subscribed multicast groups (e.g., mDNS 224.0.0.251).",
                ),
            )
            a >= 240 -> ClassificationInfo(
                "Reserved / Broadcast",
                "Non-Routable",
                "RFC 1112 / RFC 919",
                listOf(
                    "240.0.0.0/4 is reserved for future/experimental use; 255.255.255.255 is limited broadcast.",
                ),
            )
            else -> ClassificationInfo(
                "Public Unicast IPv4",
                "Globally Routable Internet Address",
                "RFC 791 / IANA Unicast",
                listOf(
                    "Globally routable addresses are allocated by IANA through Regional Internet Registries (ARIN, RIPE, APNIC, LACNIC, AFRINIC).",
                    "CYBERFORGE validates IP structure offline and never scans or probes remote hosts.",
                ),
            )
        }
    }

    private fun classifyIpv6(bytes: ByteArray, zonePart: String): ClassificationInfo {
        val isAllZeroExceptLast = bytes.dropLast(1).all { it.toInt() == 0 }
        val last = bytes.last().toInt() and 0xFF
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF

        val zoneNote = if (zonePart.isNotEmpty()) {
            listOf("Zone index '%$zonePart' specifies a local interface scope.")
        } else {
            emptyList()
        }

        return when {
            isAllZeroExceptLast && last == 0 -> ClassificationInfo(
                "Unspecified IPv6 (::)",
                "Non-Routable",
                "RFC 4291",
                listOf("Equivalent to IPv4 0.0.0.0; represents absence of an address.") + zoneNote,
            )
            isAllZeroExceptLast && last == 1 -> ClassificationInfo(
                "IPv6 Loopback (::1)",
                "Host-Local Only",
                "RFC 4291",
                listOf("Equivalent to IPv4 127.0.0.1; never leaves the local host.") + zoneNote,
            )
            b0 == 0xFE && (b1 and 0xC0) == 0x80 -> ClassificationInfo(
                "Link-Local Unicast (fe80::/10)",
                "Single Layer-2 Link Only",
                "RFC 4291",
                listOf(
                    "Automatically configured on every IPv6-capable interface for Neighbor Discovery (NDP).",
                    "Routers never forward link-local packets across subnets.",
                ) + zoneNote,
            )
            (b0 and 0xFE) == 0xFC -> ClassificationInfo(
                "Unique Local Address — ULA (fc00::/7)",
                "Private Network (Internal Only)",
                "RFC 4193",
                listOf("IPv6 counterpart to RFC 1918 private addresses; fd00::/8 uses randomized 40-bit global IDs.") + zoneNote,
            )
            b0 == 0xFF -> ClassificationInfo(
                "IPv6 Multicast (ff00::/8)",
                "Multicast Scope",
                "RFC 4291",
                listOf("Replaces IPv4 broadcast; used for router solicitation (ff02::2) and all-nodes (ff02::1).") + zoneNote,
            )
            b0 == 0x20 && b1 == 0x01 && b2 == 0x0D && b3 == 0xB8 -> ClassificationInfo(
                "IPv6 Documentation Prefix (2001:db8::/32)",
                "Non-Routable (Documentation)",
                "RFC 3849",
                listOf("Reserved strictly for examples, training, and documentation.") + zoneNote,
            )
            (b0 and 0xE0) == 0x20 -> ClassificationInfo(
                "Global Unicast IPv6 (2000::/3)",
                "Globally Routable Internet Address",
                "RFC 3587",
                listOf(
                    "Standard public IPv6 range. Typically assigned as /48 or /56 site prefixes with /64 LAN subnets.",
                    "Zero active probing or scanning is performed by CYBERFORGE.",
                ) + zoneNote,
            )
            else -> ClassificationInfo(
                "Special-Purpose / Reserved IPv6",
                "Check IANA IPv6 Registry",
                "RFC 6890",
                listOf("Falls outside standard global unicast (2000::/3) or link-local ranges.") + zoneNote,
            )
        }
    }
}
