package com.example.data

enum class LessonTopic(val label: String) {
    NETWORKING("Networking Basics"),
    LINUX("Linux Basics"),
    WEB_SECURITY("Web Security"),
    ETHICAL_HACKING("Ethical Hacking"),
    OWASP("OWASP Top 10"),
}

data class LessonQuiz(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
)

data class LessonModule(
    val id: String,
    val topic: LessonTopic,
    val title: String,
    val level: String,
    val readMinutes: Int,
    val overview: String,
    val keyPoints: List<String>,
    val terminalSnippet: String,
    val quiz: LessonQuiz,
)

object LearningRepository {

    val securityTips: List<SecurityTip> = listOf(
        SecurityTip(
            id = "tip_mfa",
            category = "IDENTITY",
            title = "Prefer FIDO2 / Passkeys Over SMS MFA",
            summary = "SMS one-time codes are vulnerable to SIM swapping and SS7 interception. Use hardware security keys or authenticator apps whenever supported.",
        ),
        SecurityTip(
            id = "tip_csp",
            category = "WEB DEFENSE",
            title = "Lock Down Scripts with Content-Security-Policy",
            summary = "Avoid 'unsafe-inline' in script-src. Using cryptographic nonces or hashes neutralizes most Cross-Site Scripting (XSS) payloads.",
        ),
        SecurityTip(
            id = "tip_least_priv",
            category = "LINUX & OPS",
            title = "Apply Principle of Least Privilege to Services",
            summary = "Run web daemons and containers as unprivileged non-root accounts so a single application compromise does not yield full host control.",
        ),
        SecurityTip(
            id = "tip_hsts",
            category = "TRANSPORT",
            title = "Enforce HSTS Only After Full HTTPS Readiness",
            summary = "Strict-Transport-Security tells browsers to refuse plaintext HTTP for months. Verify all subdomains support TLS before setting includeSubDomains.",
        ),
        SecurityTip(
            id = "tip_passphrase",
            category = "PASSWORDS",
            title = "Length Beats Complexity Tricks",
            summary = "Replacing 'a' with '@' or appending '1!' is trivial for rule-based crackers. Four or five unrelated random words offer far higher real entropy.",
        ),
        SecurityTip(
            id = "tip_scope",
            category = "ETHICS",
            title = "Never Test Without Explicit Written Scope",
            summary = "Authorized penetration testing starts with signed permission defining exact IP ranges, domains, testing windows, and emergency contacts.",
        ),
    )

    val lessons: List<LessonModule> = listOf(
        LessonModule(
            id = "net_osi_tcpip",
            topic = LessonTopic.NETWORKING,
            title = "OSI vs TCP/IP & Common Ports",
            level = "Beginner",
            readMinutes = 5,
            overview = "Every packet travels through layered abstractions. Understanding which layer handles IP routing (Layer 3), TCP/UDP ports (Layer 4), and HTTP/TLS (Layer 7) helps defenders read firewall logs and pinpoint attacks.",
            keyPoints = listOf(
                "Layer 3 (Network): IPv4/IPv6 addressing and routing between subnets.",
                "Layer 4 (Transport): TCP guarantees ordered delivery via 3-way handshake (SYN, SYN-ACK, ACK); UDP is connectionless and fast.",
                "Well-known ports: 22 (SSH), 53 (DNS), 80 (HTTP), 443 (HTTPS).",
                "Firewalls filter traffic primarily by source/destination IP, protocol, and port.",
            ),
            terminalSnippet = "$ ss -tulnp\n# Lists listening TCP (-t) & UDP (-u) sockets with numeric ports",
            quiz = LessonQuiz(
                question = "Which TCP/IP layer handles IP addressing and packet routing across networks?",
                options = listOf(
                    "Layer 2 (Data Link)",
                    "Layer 3 (Network)",
                    "Layer 7 (Application)",
                ),
                correctIndex = 1,
                explanation = "Layer 3 (Network) handles logical IP addresses and routing between networks.",
            ),
        ),
        LessonModule(
            id = "net_dns_tls",
            topic = LessonTopic.NETWORKING,
            title = "DNS Resolution & TLS 1.3 Handshake",
            level = "Beginner",
            readMinutes = 6,
            overview = "Before an HTTPS page loads, your device translates human-readable domain names into IP addresses via DNS, then establishes an encrypted, server-authenticated channel using TLS 1.3.",
            keyPoints = listOf(
                "DNS records: A maps to IPv4, AAAA maps to IPv6, MX handles email routing, TXT stores verification/SPF records.",
                "TLS 1.3 completes key exchange and server certificate verification in a single round trip (1-RTT).",
                "Certificates prove domain ownership via trusted Certificate Authorities (CAs).",
                "Never disable certificate validation in clients—doing so enables silent Man-in-the-Middle attacks.",
            ),
            terminalSnippet = "$ dig +short AAAA example.com\n2606:2800:21f:cb07:6820:80da:af6b:8b2c",
            quiz = LessonQuiz(
                question = "Which DNS record type maps a domain name to an IPv6 address?",
                options = listOf("A record", "AAAA record", "CNAME record"),
                correctIndex = 1,
                explanation = "AAAA (quad-A) records store 128-bit IPv6 addresses, while A records store 32-bit IPv4 addresses.",
            ),
        ),
        LessonModule(
            id = "linux_perms",
            topic = LessonTopic.LINUX,
            title = "Linux File Permissions & Ownership",
            level = "Beginner",
            readMinutes = 5,
            overview = "Linux enforces access control on every file, directory, and device node using user (u), group (g), and other (o) permission bits: Read (4), Write (2), and Execute (1).",
            keyPoints = listOf(
                "chmod 600 private.key restricts read/write strictly to the file owner—essential for SSH keys.",
                "Avoid chmod 777 in production; it grants write and execute rights to every local user.",
                "Sticky bit (+t) on /tmp prevents users from deleting files owned by others.",
                "Audit SUID binaries regularly because they run with the file owner's privileges.",
            ),
            terminalSnippet = "$ chmod 600 ~/.ssh/id_ed25519\n$ ls -l ~/.ssh/id_ed25519\n-rw------- 1 analyst analyst 411 Nov 18 09:00 id_ed25519",
            quiz = LessonQuiz(
                question = "What octal permission gives the owner read+write (no execute) and blocks group/others?",
                options = listOf("644", "600", "755"),
                correctIndex = 1,
                explanation = "6 (4+2) grants read+write to the owner, and 00 denies all permissions to group and others.",
            ),
        ),
        LessonModule(
            id = "linux_logs",
            topic = LessonTopic.LINUX,
            title = "Process Monitoring & Security Logs",
            level = "Beginner",
            readMinutes = 6,
            overview = "SOC analysts inspect running processes and system logs in /var/log to detect unauthorized persistence, failed SSH logins, and unexpected daemon restarts.",
            keyPoints = listOf(
                "/var/log/auth.log (Debian/Ubuntu) or /var/log/secure (RHEL) records authentication events and sudo usage.",
                "journalctl -u sshd --since '1 hour ago' filters systemd logs by service and time window.",
                "ps aux and top show process ownership, PID, and command arguments.",
                "Always preserve log timestamps in UTC to correlate events across distributed hosts.",
            ),
            terminalSnippet = "$ journalctl -u ssh --since \"2 hours ago\" --no-pager | tail -n 20",
            quiz = LessonQuiz(
                question = "Why do SOC teams standardize server timestamps on UTC?",
                options = listOf(
                    "UTC compresses log files smaller on disk",
                    "It prevents timezone and daylight-saving ambiguity during incident correlation",
                    "Linux kernels cannot store local timezones",
                ),
                correctIndex = 1,
                explanation = "UTC gives a single unambiguous timeline when correlating logs across servers in multiple regions.",
            ),
        ),
        LessonModule(
            id = "web_sop_cors",
            topic = LessonTopic.WEB_SECURITY,
            title = "Same-Origin Policy, CORS & Cookies",
            level = "Beginner",
            readMinutes = 6,
            overview = "Browsers isolate websites by Origin (scheme + host + port). Misconfigured CORS headers or missing cookie flags can expose authenticated user sessions across origins.",
            keyPoints = listOf(
                "An Origin consists of Scheme (https), Host (app.example.com), and Port (443).",
                "Never combine Access-Control-Allow-Credentials: true with wildcard or unvalidated Origin reflection.",
                "Set HttpOnly on session cookies so JavaScript cannot read them via document.cookie.",
                "Combine Secure (HTTPS only) and SameSite=Lax/Strict to mitigate CSRF.",
            ),
            terminalSnippet = "Set-Cookie: session_id=opaque_token; Path=/; Secure; HttpOnly; SameSite=Lax",
            quiz = LessonQuiz(
                question = "Which cookie attribute prevents client-side JavaScript from reading the cookie via document.cookie?",
                options = listOf("Secure", "HttpOnly", "SameSite=None"),
                correctIndex = 1,
                explanation = "HttpOnly blocks JavaScript access to the cookie, limiting session theft if XSS occurs.",
            ),
        ),
        LessonModule(
            id = "web_headers_defense",
            topic = LessonTopic.WEB_SECURITY,
            title = "Defense-in-Depth Security Headers",
            level = "Beginner",
            readMinutes = 5,
            overview = "HTTP security headers instruct browsers how to handle scripts, frames, MIME types, and TLS downgrades—providing a crucial safety net even when application bugs appear.",
            keyPoints = listOf(
                "Content-Security-Policy restricts where scripts, styles, and frames can load from.",
                "Strict-Transport-Security forces HTTPS for subsequent visits.",
                "X-Content-Type-Options: nosniff prevents MIME confusion attacks.",
                "X-Frame-Options: DENY (or CSP frame-ancestors 'none') stops clickjacking.",
            ),
            terminalSnippet = "Strict-Transport-Security: max-age=31536000; includeSubDomains\nX-Content-Type-Options: nosniff\nX-Frame-Options: DENY",
            quiz = LessonQuiz(
                question = "Which header stops browsers from guessing a file's executable MIME type against the server's Content-Type?",
                options = listOf(
                    "X-Content-Type-Options: nosniff",
                    "Referrer-Policy: no-referrer",
                    "Permissions-Policy",
                ),
                correctIndex = 0,
                explanation = "X-Content-Type-Options: nosniff forces browsers to honor the declared Content-Type.",
            ),
        ),
        LessonModule(
            id = "ethical_roe",
            topic = LessonTopic.ETHICAL_HACKING,
            title = "Rules of Engagement & Responsible Disclosure",
            level = "Beginner",
            readMinutes = 5,
            overview = "What separates an ethical security researcher from an attacker is explicit authorization, strict scope boundaries, data minimization, and coordinated vulnerability disclosure.",
            keyPoints = listOf(
                "Always obtain signed written authorization before testing any system you do not personally own.",
                "Respect scope: out-of-scope subdomains, third-party SaaS APIs, and denial-of-service tests are strictly off-limits.",
                "If you accidentally encounter sensitive PII during an authorized test, stop immediately and report it securely.",
                "Look for security.txt (/.well-known/security.txt) when reporting discovered flaws responsibly.",
            ),
            terminalSnippet = "$ curl -s https://example.com/.well-known/security.txt\nContact: mailto:security@example.com",
            quiz = LessonQuiz(
                question = "What standard file helps researchers find an organization's vulnerability reporting contact?",
                options = listOf(
                    "robots.txt",
                    "/.well-known/security.txt",
                    "/etc/passwd",
                ),
                correctIndex = 1,
                explanation = "RFC 9116 defines /.well-known/security.txt for standardized vulnerability disclosure contacts.",
            ),
        ),
        LessonModule(
            id = "owasp_top10_core",
            topic = LessonTopic.OWASP,
            title = "OWASP Top 10 Essentials (A01–A05)",
            level = "Intermediate",
            readMinutes = 7,
            overview = "The OWASP Top 10 highlights the most critical web application security risks. Learning how Broken Access Control, Cryptographic Failures, and Injection work empowers developers to build resilient systems.",
            keyPoints = listOf(
                "A01 Broken Access Control: Always enforce authorization checks server-side for every object ID (prevent IDOR).",
                "A02 Cryptographic Failures: Use TLS 1.2+/1.3 in transit and Argon2id/bcrypt for password hashing—never MD5/SHA-1.",
                "A03 Injection: Use parameterized queries / prepared statements instead of string concatenation in SQL.",
                "A05 Security Misconfiguration: Remove default credentials, disable debug stack traces, and enforce security headers.",
            ),
            terminalSnippet = "// Safe parameterized SQL (never concatenate user input)\nSELECT id, role FROM users WHERE email = ?;",
            quiz = LessonQuiz(
                question = "What is the most reliable defense against SQL Injection (OWASP A03)?",
                options = listOf(
                    "Hiding database error messages in HTML comments",
                    "Using parameterized queries / prepared statements",
                    "Checking input length only in the frontend UI",
                ),
                correctIndex = 1,
                explanation = "Parameterized queries keep SQL structure strictly separated from user-supplied data values.",
            ),
        ),
        LessonModule(
            id = "owasp_ssrf_auth",
            topic = LessonTopic.OWASP,
            title = "OWASP Top 10: Auth Failures & SSRF (A07, A10)",
            level = "Intermediate",
            readMinutes = 6,
            overview = "Authentication weaknesses and Server-Side Request Forgery (SSRF) frequently lead to full cloud account takeover when servers fetch arbitrary user-supplied URLs.",
            keyPoints = listOf(
                "A07 Authentication Failures: Enforce rate limiting, MFA, and strong password entropy without leaking account existence.",
                "A10 SSRF: Never let a server fetch unvalidated user URLs that could reach internal IPs like 127.0.0.1 or 169.254.169.254.",
                "Use allowlists for permitted external hostnames and block private/link-local IP ranges after DNS resolution.",
            ),
            terminalSnippet = "# Cloud metadata IP frequently targeted by SSRF (block at network & app layer):\n169.254.169.254/32",
            quiz = LessonQuiz(
                question = "Why is 169.254.169.254 dangerous when an application is vulnerable to SSRF?",
                options = listOf(
                    "It is a public DNS root server",
                    "Cloud instances expose metadata and temporary IAM credentials on that link-local IP",
                    "It crashes the TLS handshake",
                ),
                correctIndex = 1,
                explanation = "Cloud providers host instance metadata services at 169.254.169.254, making it a primary SSRF target.",
            ),
        ),
    )
}
