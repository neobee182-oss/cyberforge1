package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.AccentTheme

@Immutable
data class CyberPalette(
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val pass: Color,
    val info: Color,
    val warn: Color,
    val fail: Color,
    val unavailable: Color,
)

val LocalCyberPalette = staticCompositionLocalOf {
    CyberPalette(
        primaryAccent = NeonGreen,
        secondaryAccent = ElectricCyan,
        background = ObsidianBlack,
        surface = TerminalSurface,
        surfaceElevated = TerminalElevated,
        border = TerminalBorder,
        textPrimary = TextPrimary,
        textSecondary = TextSecondary,
        textMuted = TextMuted,
        pass = StatusPass,
        info = StatusInfo,
        warn = StatusWarn,
        fail = StatusFail,
        unavailable = StatusUnavailable,
    )
}

private val CyberShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun CyberForgeTheme(
    accentTheme: AccentTheme = AccentTheme.CYBER_MATRIX,
    highContrastBorders: Boolean = false,
    content: @Composable () -> Unit,
) {
    val (primary, secondary, tertiary) = when (accentTheme) {
        AccentTheme.CYBER_MATRIX -> Triple(NeonGreen, ElectricCyan, PlasmaViolet)
        AccentTheme.COBALT_SENTINEL -> Triple(ElectricCyan, SkyPulse, NeonGreen)
        AccentTheme.STEALTH_AMBER -> Triple(TacticalAmber, ElectricCyan, NeonGreen)
    }

    val borderColor = if (highContrastBorders) TerminalBorderBright else TerminalBorder

    val palette = CyberPalette(
        primaryAccent = primary,
        secondaryAccent = secondary,
        background = ObsidianBlack,
        surface = TerminalSurface,
        surfaceElevated = TerminalElevated,
        border = borderColor,
        textPrimary = TextPrimary,
        textSecondary = TextSecondary,
        textMuted = TextMuted,
        pass = StatusPass,
        info = StatusInfo,
        warn = StatusWarn,
        fail = StatusFail,
        unavailable = StatusUnavailable,
    )

    val colorScheme = darkColorScheme(
        primary = primary,
        onPrimary = ObsidianBlack,
        primaryContainer = primary.copy(alpha = 0.16f),
        onPrimaryContainer = primary,
        secondary = secondary,
        onSecondary = ObsidianBlack,
        secondaryContainer = secondary.copy(alpha = 0.16f),
        onSecondaryContainer = secondary,
        tertiary = tertiary,
        onTertiary = ObsidianBlack,
        background = ObsidianBlack,
        onBackground = TextPrimary,
        surface = TerminalSurface,
        onSurface = TextPrimary,
        surfaceVariant = TerminalElevated,
        onSurfaceVariant = TextSecondary,
        surfaceContainerLowest = ObsidianBlack,
        surfaceContainerLow = TerminalSurface,
        surfaceContainer = TerminalElevated,
        surfaceContainerHigh = TerminalCardAlt,
        outline = borderColor,
        outlineVariant = TerminalBorder,
        error = StatusFail,
        onError = ObsidianBlack,
        errorContainer = StatusFail.copy(alpha = 0.16f),
        onErrorContainer = StatusFail,
    )

    CompositionLocalProvider(LocalCyberPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CyberTypography,
            shapes = CyberShapes,
            content = content,
        )
    }
}
