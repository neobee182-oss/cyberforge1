package com.example.engine

import java.net.InetAddress
import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class DnsCheckResult(
    val status: DnsLookupStatus,
    val resolvedAddresses: List<String>,
    val note: String,
)

enum class DnsLookupStatus {
    RESOLVED,
    FAILED,
    DISABLED_OFFLINE_MODE,
    NOT_APPLICABLE,
}

data class DomainCheckItem(
    val label: String,
    val value: String,
    val isWarning: Boolean = false,
)

data class DomainAnalysisResult(
    val rawInput: String,
    val normalizedTarget: String,
    val protocol: String,
    val hostname: String,
    val rootDomain: String,
    val tld: String,
    val subdomainLabels: List<String>,
    val port: Int?,
    val path: String,
    val hasPunycode: Boolean,
    val isIpLiteral: Boolean,
    val formatChecks: List<DomainCheckItem>,
    val dnsResult: DnsCheckResult,
    val unavailableChecks: List<String>,
)

object DomainAnalyzer {

    private val labelRegex = Regex("^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$")
    private val tldRegex = Regex("^[a-zA-Z]{2,63}$|^xn--[a-zA-Z0-9]{2,59}$")

    suspend fun analyze(
        rawInput: String,
        liveNetworkEnabled: Boolean,
        timeoutSeconds: Int,
    ): Result<DomainAnalysisResult> {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter a domain name or URL (e.g. example.com or https://app.example.com)."))
        }
        if (trimmed.contains(" ")) {
            return Result.failure(IllegalArgumentException("Domains and URLs cannot contain whitespace."))
        }

        val hasExplicitScheme = trimmed.contains("://")
        val candidateUriText = if (hasExplicitScheme) trimmed else "https://$trimmed"

        val uri = try {
            URI(candidateUriText)
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("Malformed URL/domain syntax: ${e.localizedMessage ?: "parse failure"}."))
        }

        val scheme = if (hasExplicitScheme) (uri.scheme?.lowercase() ?: "unspecified") else "unspecified (defaulted to https for parse)"
        val host = uri.host?.lowercase()?.trimEnd('.')
            ?: return Result.failure(IllegalArgumentException("Could not extract a valid hostname from '$trimmed'."))

        if (host.length > 253) {
            return Result.failure(IllegalArgumentException("Hostname exceeds RFC 1035 maximum length of 253 characters (${host.length})."))
        }

        val isIpLiteral = IpAnalyzer.isValidIp(host)
        val labels = host.split(".")

        if (!isIpLiteral) {
            if (labels.size < 2) {
                return Result.failure(IllegalArgumentException("Hostname '$host' must contain a domain and top-level domain (e.g. example.com)."))
            }
            for (label in labels) {
                if (!labelRegex.matches(label)) {
                    return Result.failure(IllegalArgumentException("Invalid DNS label '$label'. Labels must be 1–63 alphanumeric/hyphen chars and not start or end with '-'."))
                }
            }
            val tld = labels.last()
            if (!tldRegex.matches(tld)) {
                return Result.failure(IllegalArgumentException("Invalid top-level domain '.$tld'."))
            }
        }

        val tld = if (isIpLiteral) "N/A (IP Literal)" else ".${labels.last()}"
        val rootDomain = if (isIpLiteral || labels.size <= 2) host else labels.takeLast(2).joinToString(".")
        val subdomains = if (isIpLiteral || labels.size <= 2) emptyList() else labels.dropLast(2)
        val hasPunycode = labels.any { it.startsWith("xn--") }
        val port = if (uri.port != -1) uri.port else null
        val path = uri.rawPath?.takeIf { it.isNotEmpty() } ?: "/"

        val formatChecks = buildList {
            add(
                DomainCheckItem(
                    label = "Transport Protocol",
                    value = when {
                        !hasExplicitScheme -> "Not specified in input (recommend explicit https://)"
                        scheme == "https" -> "HTTPS (encrypted transport specified)"
                        scheme == "http" -> "HTTP (plaintext — vulnerable to interception)"
                        else -> scheme.uppercase()
                    },
                    isWarning = scheme == "http",
                ),
            )
            add(
                DomainCheckItem(
                    label = "RFC 1123 Syntax",
                    value = if (isIpLiteral) "Valid IP literal used as host" else "Valid (${labels.size} labels, ${host.length} chars)",
                ),
            )
            add(
                DomainCheckItem(
                    label = "IDN / Punycode",
                    value = if (hasPunycode) "Punycode label detected (verify visually against homograph spoofing)" else "ASCII only (no xn-- labels)",
                    isWarning = hasPunycode,
                ),
            )
            add(
                DomainCheckItem(
                    label = "Subdomain Depth",
                    value = if (subdomains.isEmpty()) "Apex / root level" else "${subdomains.size} level(s): ${subdomains.joinToString(".")}",
                ),
            )
        }

        val dnsResult = when {
            isIpLiteral -> DnsCheckResult(
                status = DnsLookupStatus.NOT_APPLICABLE,
                resolvedAddresses = emptyList(),
                note = "Input is already an IP literal; DNS resolution skipped.",
            )
            !liveNetworkEnabled -> DnsCheckResult(
                status = DnsLookupStatus.DISABLED_OFFLINE_MODE,
                resolvedAddresses = emptyList(),
                note = "Live DNS checks are disabled in Settings (Strict Offline Mode).",
            )
            else -> performSafeDnsLookup(host, timeoutSeconds)
        }

        val unavailableChecks = listOf(
            "WHOIS / Registrar Ownership (no external WHOIS scraper configured)",
            "Active Port & Service Scanning (intentionally disabled — passive mode only)",
            "Subdomain Brute-Force Enumeration (not performed)",
            "Vulnerability / Exploit Probing (prohibited in passive workbench)",
        )

        return Result.success(
            DomainAnalysisResult(
                rawInput = trimmed,
                normalizedTarget = if (hasExplicitScheme) trimmed else "https://$host",
                protocol = if (hasExplicitScheme) scheme.uppercase() else "UNSPECIFIED",
                hostname = host,
                rootDomain = rootDomain,
                tld = tld,
                subdomainLabels = subdomains,
                port = port,
                path = path,
                hasPunycode = hasPunycode,
                isIpLiteral = isIpLiteral,
                formatChecks = formatChecks,
                dnsResult = dnsResult,
                unavailableChecks = unavailableChecks,
            ),
        )
    }

    private suspend fun performSafeDnsLookup(hostname: String, timeoutSeconds: Int): DnsCheckResult =
        withContext(Dispatchers.IO) {
            val lookup = withTimeoutOrNull(timeoutSeconds * 1000L) {
                runCatching {
                    InetAddress.getAllByName(hostname).mapNotNull { it.hostAddress }.distinct()
                }
            }
            when {
                lookup == null -> DnsCheckResult(
                    status = DnsLookupStatus.FAILED,
                    resolvedAddresses = emptyList(),
                    note = "DNS lookup timed out after ${timeoutSeconds}s.",
                )
                lookup.isFailure -> DnsCheckResult(
                    status = DnsLookupStatus.FAILED,
                    resolvedAddresses = emptyList(),
                    note = "DNS unavailable or NXDOMAIN: ${lookup.exceptionOrNull()?.localizedMessage ?: "resolution failed"}",
                )
                else -> {
                    val addrs = lookup.getOrDefault(emptyList())
                    if (addrs.isEmpty()) {
                        DnsCheckResult(
                            status = DnsLookupStatus.FAILED,
                            resolvedAddresses = emptyList(),
                            note = "No A/AAAA records returned by system resolver.",
                        )
                    } else {
                        DnsCheckResult(
                            status = DnsLookupStatus.RESOLVED,
                            resolvedAddresses = addrs,
                            note = "Resolved ${addrs.size} address(es) via standard system DNS resolver.",
                        )
                    }
                }
            }
        }
}
