package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.LearningRepository
import com.example.data.LessonModule
import com.example.data.LessonTopic
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette

@Composable
fun LearningCenterScreen(
    selectedTopic: LessonTopic?,
    completedLessonIds: Set<String>,
    isWideScreen: Boolean,
    onSelectTopic: (LessonTopic?) -> Unit,
    onMarkCompleted: (String) -> Unit,
) {
    val palette = LocalCyberPalette.current
    val filteredLessons = remember(selectedTopic) {
        if (selectedTopic == null) {
            LearningRepository.lessons
        } else {
            LearningRepository.lessons.filter { it.topic == selectedTopic }
        }
    }

    var activeLesson by remember { mutableStateOf<LessonModule?>(null) }

    if (activeLesson != null && !isWideScreen) {
        BackHandler { activeLesson = null }
        LessonDetailPane(
            lesson = activeLesson!!,
            isCompleted = activeLesson!!.id in completedLessonIds,
            showBackButton = true,
            onBack = { activeLesson = null },
            onComplete = { onMarkCompleted(activeLesson!!.id) },
        )
        return
    }

    if (isWideScreen) {
        val currentSelection = activeLesson ?: filteredLessons.firstOrNull()
        Row(
            modifier = Modifier.fillMaxSize(),
        ) {
            LessonListPane(
                selectedTopic = selectedTopic,
                lessons = filteredLessons,
                completedLessonIds = completedLessonIds,
                activeLessonId = currentSelection?.id,
                onSelectTopic = onSelectTopic,
                onSelectLesson = { activeLesson = it },
                modifier = Modifier.weight(0.45f),
            )
            if (currentSelection != null) {
                LessonDetailPane(
                    lesson = currentSelection,
                    isCompleted = currentSelection.id in completedLessonIds,
                    showBackButton = false,
                    onBack = { activeLesson = null },
                    onComplete = { onMarkCompleted(currentSelection.id) },
                    modifier = Modifier.weight(0.55f),
                )
            }
        }
    } else {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
        ) {
            LessonListPane(
                selectedTopic = selectedTopic,
                lessons = filteredLessons,
                completedLessonIds = completedLessonIds,
                activeLessonId = null,
                onSelectTopic = onSelectTopic,
                onSelectLesson = { activeLesson = it },
                modifier = Modifier.widthIn(max = 900.dp),
            )
        }
    }
}

@Composable
private fun LessonListPane(
    selectedTopic: LessonTopic?,
    lessons: List<LessonModule>,
    completedLessonIds: Set<String>,
    activeLessonId: String?,
    onSelectTopic: (LessonTopic?) -> Unit,
    onSelectLesson: (LessonModule) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SocTerminalCard(
                terminalTag = "// CYBERFORGE_LEARNING_CENTER",
                accentColor = palette.primaryAccent,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.School,
                            contentDescription = null,
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(22.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Security Curriculum",
                            style = MaterialTheme.typography.headlineSmall,
                            color = palette.textPrimary,
                        )
                    }
                    StatusBadge(
                        label = "${completedLessonIds.size}/${LearningRepository.lessons.size} DONE",
                        color = palette.primaryAccent,
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Beginner-friendly modules covering Networking, Linux, Web Security, Ethical Hacking, and OWASP Top 10.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = selectedTopic == null,
                        onClick = { onSelectTopic(null) },
                        label = { Text("All Tracks") },
                        modifier = Modifier.testTag("topic_filter_all"),
                    )
                    LessonTopic.entries.forEach { topic ->
                        FilterChip(
                            selected = selectedTopic == topic,
                            onClick = { onSelectTopic(topic) },
                            label = { Text(topic.label) },
                            modifier = Modifier.testTag("topic_filter_${topic.name.lowercase()}"),
                        )
                    }
                }
            }
        }

        items(lessons, key = { it.id }) { lesson ->
            val isCompleted = lesson.id in completedLessonIds
            val isSelected = lesson.id == activeLessonId
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(MaterialTheme.shapes.medium)
                    .clickable { onSelectLesson(lesson) }
                    .testTag("lesson_card_${lesson.id}"),
                shape = MaterialTheme.shapes.medium,
                color = if (isSelected) palette.surfaceElevated else palette.surface,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isSelected) palette.primaryAccent else palette.border,
                ),
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            StatusBadge(label = lesson.topic.label.uppercase(), color = palette.secondaryAccent)
                            Text(
                                text = "${lesson.level} • ${lesson.readMinutes}m",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textMuted,
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lesson.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = lesson.overview,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                            maxLines = 2,
                        )
                    }
                    Icon(
                        imageVector = if (isCompleted) Icons.Filled.CheckCircle else Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = if (isCompleted) "Completed" else "Open lesson",
                        tint = if (isCompleted) palette.pass else palette.textMuted,
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun LessonDetailPane(
    lesson: LessonModule,
    isCompleted: Boolean,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    var selectedAnswer by remember(lesson.id) { mutableIntStateOf(-1) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SocTerminalCard(
                terminalTag = "// LESSON_MODULE • ${lesson.topic.label.uppercase()}",
                accentColor = palette.secondaryAccent,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (showBackButton) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("lesson_back_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to lessons",
                                tint = palette.textPrimary,
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = lesson.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = palette.textPrimary,
                        )
                        Text(
                            text = "${lesson.level} • ${lesson.readMinutes} min read",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textMuted,
                        )
                    }
                    if (isCompleted) {
                        StatusBadge(label = "COMPLETED", color = palette.pass)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = lesson.overview,
                    style = MaterialTheme.typography.bodyLarge,
                    color = palette.textPrimary,
                )

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = palette.border)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "KEY TAKEAWAYS",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent,
                )
                Spacer(modifier = Modifier.height(8.dp))
                lesson.keyPoints.forEach { point ->
                    Text(
                        text = "• $point",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = palette.background,
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = lesson.terminalSnippet,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.primaryAccent,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
        }

        item {
            SocTerminalCard(
                terminalTag = "// KNOWLEDGE_CHECK_QUIZ",
                accentColor = palette.primaryAccent,
            ) {
                Text(
                    text = lesson.quiz.question,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                )
                Spacer(modifier = Modifier.height(12.dp))

                lesson.quiz.options.forEachIndexed { idx, option ->
                    val isPicked = selectedAnswer == idx
                    val isRight = idx == lesson.quiz.correctIndex
                    val borderColor = when {
                        selectedAnswer == -1 -> palette.border
                        isRight -> palette.pass
                        isPicked -> palette.fail
                        else -> palette.border
                    }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                selectedAnswer = idx
                                if (idx == lesson.quiz.correctIndex) {
                                    onComplete()
                                }
                            }
                            .testTag("quiz_option_$idx"),
                        shape = RoundedCornerShape(10.dp),
                        color = palette.surfaceElevated,
                        border = BorderStroke(1.dp, borderColor),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(
                                imageVector = if (isPicked || (selectedAnswer != -1 && isRight)) {
                                    Icons.Filled.CheckCircle
                                } else {
                                    Icons.Outlined.RadioButtonUnchecked
                                },
                                contentDescription = null,
                                tint = borderColor,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                text = option,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textPrimary,
                            )
                        }
                    }
                }

                if (selectedAnswer != -1) {
                    val correct = selectedAnswer == lesson.quiz.correctIndex
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (correct) "Correct! ${lesson.quiz.explanation}" else "Not quite. ${lesson.quiz.explanation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (correct) palette.pass else palette.warn,
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
