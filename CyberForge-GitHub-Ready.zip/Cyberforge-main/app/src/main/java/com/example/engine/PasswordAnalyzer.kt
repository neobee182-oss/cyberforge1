package com.example.engine

import java.security.SecureRandom
import kotlin.math.log2

enum class StrengthTier(val label: String, val fraction: Float) {
    CRITICAL("Critical", 0.16f),
    WEAK("Weak", 0.34f),
    MODERATE("Moderate", 0.58f),
    STRONG("Strong", 0.82f),
    FORTIFIED("Fortified", 1.0f),
}

data class PasswordPatternFinding(
    val title: String,
    val detail: String,
    val severity: PatternSeverity,
)

enum class PatternSeverity { HIGH, MEDIUM, INFO }

data class PasswordAnalysisResult(
    val length: Int,
    val hasLowercase: Boolean,
    val hasUppercase: Boolean,
    val hasDigits: Boolean,
    val hasSymbols: Boolean,
    val uniqueChars: Int,
    val poolSize: Int,
    val entropyBits: Double,
    val effectiveBits: Double,
    val tier: StrengthTier,
    val estimatedCrackTime: String,
    val findings: List<PasswordPatternFinding>,
    val recommendations: List<String>,
)

object PasswordAnalyzer {

    private val commonTokens = listOf(
        "password", "passw0rd", "admin", "administrator", "welcome", "letmein",
        "qwerty", "asdf", "zxcv", "dragon", "baseball", "football", "monkey",
        "master", "login", "root", "toor", "cyber", "secret", "iloveyou",
        "trustno1", "sunshine", "princess", "charlie", "shadow", "test123",
    )

    private val keyboardRows = listOf(
        "qwertyuiop",
        "asdfghjkl",
        "zxcvbnm",
        "1234567890",
        "0987654321",
        "abcdefghijklmnopqrstuvwxyz",
        "zyxwvutsrqponmlkjihgfedcba",
    )

    private val yearRegex = Regex("(19\\d{2}|20[0-3]\\d)")
    private val repeatRegex = Regex("(.)\\1{2,}")

    private val random = SecureRandom()

    fun analyze(password: String): PasswordAnalysisResult {
        val length = password.length
        val hasLower = password.any { it in 'a'..'z' }
        val hasUpper = password.any { it in 'A'..'Z' }
        val hasDigits = password.any { it in '0'..'9' }
        val hasSymbols = password.any { !it.isLetterOrDigit() }
        val uniqueChars = password.toSet().size

        var pool = 0
        if (hasLower) pool += 26
        if (hasUpper) pool += 26
        if (hasDigits) pool += 10
        if (hasSymbols) pool += 33
        if (password.any { it.code > 127 }) pool += 64

        val theoreticalEntropy = if (length > 0 && pool > 0) {
            length * log2(pool.toDouble())
        } else {
            0.0
        }

        val findings = mutableListOf<PasswordPatternFinding>()
        var penaltyBits = 0.0

        val lowerInput = password.lowercase()

        if (length < 8) {
            findings += PasswordPatternFinding(
                title = "Critically Short Length",
                detail = "Length is $length characters. Passwords under 8 characters can be brute-forced rapidly offline.",
                severity = PatternSeverity.HIGH,
            )
            penaltyBits += 18.0
        } else if (length < 12) {
            findings += PasswordPatternFinding(
                title = "Below Recommended Length",
                detail = "Length is $length characters. Aim for at least 12–16 characters or a multi-word passphrase.",
                severity = PatternSeverity.MEDIUM,
            )
            penaltyBits += 8.0
        }

        val matchedWords = commonTokens.filter { lowerInput.contains(it) }
        if (matchedWords.isNotEmpty()) {
            findings += PasswordPatternFinding(
                title = "Dictionary / Leaked Pattern Detected",
                detail = "Contains predictable word token(s): ${matchedWords.joinToString(", ") { "'$it'" }}.",
                severity = PatternSeverity.HIGH,
            )
            penaltyBits += 24.0
        }

        val seqHit = findSequence(lowerInput)
        if (seqHit != null) {
            findings += PasswordPatternFinding(
                title = "Sequential Keyboard / Alphabet Run",
                detail = "Contains predictable 3+ character sequence '$seqHit'.",
                severity = PatternSeverity.HIGH,
            )
            penaltyBits += 14.0
        }

        val repeatMatch = repeatRegex.find(password)
        if (repeatMatch != null) {
            findings += PasswordPatternFinding(
                title = "Repeated Character Run",
                detail = "Repeats '${repeatMatch.value}' which drastically reduces effective keyspace.",
                severity = PatternSeverity.MEDIUM,
            )
            penaltyBits += 10.0
        }

        if (yearRegex.containsMatchIn(password)) {
            findings += PasswordPatternFinding(
                title = "Date or Year Pattern",
                detail = "Contains a 4-digit year pattern (1900–2039), commonly targeted by rule-based password crackers.",
                severity = PatternSeverity.MEDIUM,
            )
            penaltyBits += 8.0
        }

        val activeClasses = listOf(hasLower, hasUpper, hasDigits, hasSymbols).count { it }
        if (activeClasses <= 1 && length > 0) {
            findings += PasswordPatternFinding(
                title = "Single Character Class",
                detail = "Uses only one character type, limiting search space per position.",
                severity = PatternSeverity.HIGH,
            )
            penaltyBits += 12.0
        }

        if (length >= 6 && uniqueChars <= length / 2) {
            findings += PasswordPatternFinding(
                title = "Low Character Diversity",
                detail = "Only $uniqueChars unique characters across $length positions.",
                severity = PatternSeverity.MEDIUM,
            )
            penaltyBits += 10.0
        }

        if (findings.isEmpty() && length >= 12) {
            findings += PasswordPatternFinding(
                title = "No Common Weak Patterns Detected",
                detail = "No sequential runs, repeated runs, years, or built-in dictionary tokens matched locally.",
                severity = PatternSeverity.INFO,
            )
        }

        val effectiveBits = (theoreticalEntropy - penaltyBits).coerceAtLeast(0.0)

        val tier = when {
            effectiveBits < 28.0 -> StrengthTier.CRITICAL
            effectiveBits < 45.0 -> StrengthTier.WEAK
            effectiveBits < 64.0 -> StrengthTier.MODERATE
            effectiveBits < 85.0 -> StrengthTier.STRONG
            else -> StrengthTier.FORTIFIED
        }

        val crackEstimate = estimateOfflineCrackTime(effectiveBits)

        val recommendations = buildList {
            if (length < 14) add("Increase length to 14+ characters (length scales entropy exponentially).")
            if (!hasUpper || !hasLower) add("Mix uppercase and lowercase characters unpredictably.")
            if (!hasDigits) add("Add non-year digits in non-trailing positions.")
            if (!hasSymbols) add("Include symbols outside common substitutions (@ for a, 0 for o).")
            if (matchedWords.isNotEmpty() || seqHit != null) {
                add("Avoid dictionary words, names, and keyboard walks like 'qwerty' or '1234'.")
            }
            add("Use a dedicated password manager and never reuse passwords across services.")
        }

        return PasswordAnalysisResult(
            length = length,
            hasLowercase = hasLower,
            hasUppercase = hasUpper,
            hasDigits = hasDigits,
            hasSymbols = hasSymbols,
            uniqueChars = uniqueChars,
            poolSize = pool,
            entropyBits = theoreticalEntropy,
            effectiveBits = effectiveBits,
            tier = tier,
            estimatedCrackTime = crackEstimate,
            findings = findings,
            recommendations = recommendations,
        )
    }

    fun generateStrongPassword(length: Int = 18): String {
        val lowers = "abcdefghijkmnopqrstuvwxyz"
        val uppers = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        val digits = "23456789"
        val symbols = "!@#$%^&*-_=+?"
        val all = lowers + uppers + digits + symbols

        val chars = mutableListOf(
            lowers[random.nextInt(lowers.length)],
            uppers[random.nextInt(uppers.length)],
            digits[random.nextInt(digits.length)],
            symbols[random.nextInt(symbols.length)],
        )
        while (chars.size < length) {
            chars += all[random.nextInt(all.length)]
        }
        chars.shuffle(random)
        return chars.joinToString("")
    }

    private fun findSequence(lower: String): String? {
        if (lower.length < 3) return null
        for (i in 0..lower.length - 3) {
            val sub = lower.substring(i, i + 3)
            if (keyboardRows.any { it.contains(sub) }) {
                return sub
            }
        }
        return null
    }

    private fun estimateOfflineCrackTime(effectiveBits: Double): String {
        // Assumes fast offline GPU benchmark ~1e10 guesses/sec (log2(1e10) ≈ 33.2 bits/sec)
        if (effectiveBits <= 1.0) return "Instant"
        val log2Seconds = effectiveBits - 33.22
        return when {
            log2Seconds < 0 -> "Under 1 second (offline GPU)"
            log2Seconds < 5.9 -> "Seconds to minutes"
            log2Seconds < 11.8 -> "Minutes to hours"
            log2Seconds < 16.4 -> "Hours to days"
            log2Seconds < 21.5 -> "Weeks to months"
            log2Seconds < 25.0 -> "Years"
            log2Seconds < 31.6 -> "Decades to centuries"
            else -> "Centuries+ (high offline resistance)"
        }
    }
}
