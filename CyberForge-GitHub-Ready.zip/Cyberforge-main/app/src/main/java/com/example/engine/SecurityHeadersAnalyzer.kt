package com.example.engine

import java.net.URI
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

enum class HeaderStatus {
    PRESENT,
    MISSING,
}

data class SecurityHeaderAuditItem(
    val headerName: String,
    val status: HeaderStatus,
    val observedValue: String?,
    val importance: String,
    val purpose: String,
    val missingRisk: String,
    val recommendedValue: String,
)

data class SecurityHeadersAnalysisResult(
    val requestedUrl: String,
    val finalUrl: String,
    val httpStatusCode: Int,
    val protocol: String,
    val isHttps: Boolean,
    val presentCount: Int,
    val totalChecked: Int,
    val headers: List<SecurityHeaderAuditItem>,
    val note: String,
)

data class SecurityHeaderGuideEntry(
    val name: String,
    val importance: String,
    val summary: String,
    val example: String,
)

object SecurityHeadersAnalyzer {

    private data class HeaderSpec(
        val name: String,
        val importance: String,
        val purpose: String,
        val missingRisk: String,
        val recommendedValue: String,
    )

    private val specs = listOf(
        HeaderSpec(
            name = "Strict-Transport-Security",
            importance = "CRITICAL",
            purpose = "Enforces HTTPS connections and prevents protocol downgrade attacks.",
            missingRisk = "First-visit HTTP requests may be vulnerable to SSL stripping.",
            recommendedValue = "max-age=31536000; includeSubDomains",
        ),
        HeaderSpec(
            name = "Content-Security-Policy",
            importance = "CRITICAL",
            purpose = "Restricts allowed script, style, frame, and network sources to mitigate XSS and data injection.",
            missingRisk = "Browsers execute inline or third-party scripts if an injection flaw exists.",
            recommendedValue = "default-src 'self'; object-src 'none'; frame-ancestors 'none'",
        ),
        HeaderSpec(
            name = "X-Frame-Options",
            importance = "HIGH",
            purpose = "Prevents the page from being embedded in external iframes (clickjacking defense).",
            missingRisk = "Attackers may overlay hidden frames to trick users into unintended clicks.",
            recommendedValue = "DENY (or SAMEORIGIN)",
        ),
        HeaderSpec(
            name = "X-Content-Type-Options",
            importance = "HIGH",
            purpose = "Stops browsers from MIME-sniffing responses away from declared Content-Type.",
            missingRisk = "Uploaded or served text/data files could be misinterpreted as executable script.",
            recommendedValue = "nosniff",
        ),
        HeaderSpec(
            name = "Referrer-Policy",
            importance = "MEDIUM",
            purpose = "Controls how much URL path/query information is leaked in the Referer header.",
            missingRisk = "Sensitive URL tokens or paths may leak to third-party origins on navigation.",
            recommendedValue = "strict-origin-when-cross-origin",
        ),
        HeaderSpec(
            name = "Permissions-Policy",
            importance = "MEDIUM",
            purpose = "Explicitly restricts browser APIs like camera, microphone, geolocation, and USB.",
            missingRisk = "Embedded third-party frames might request hardware capabilities if not constrained.",
            recommendedValue = "geolocation=(), microphone=(), camera=()",
        ),
        HeaderSpec(
            name = "Cross-Origin-Opener-Policy",
            importance = "MEDIUM",
            purpose = "Isolates browsing context group from cross-origin popups (Spectre defense).",
            missingRisk = "Cross-origin windows may share process context or window.opener references.",
            recommendedValue = "same-origin",
        ),
        HeaderSpec(
            name = "Cross-Origin-Resource-Policy",
            importance = "LOW",
            purpose = "Blocks other origins from loading sensitive subresources via <img>/<script> tags.",
            missingRisk = "Cross-site resource inclusion may expose side-channel metadata.",
            recommendedValue = "same-origin",
        ),
    )

    val referenceGuide: List<SecurityHeaderGuideEntry> = specs.map {
        SecurityHeaderGuideEntry(
            name = it.name,
            importance = it.importance,
            summary = it.purpose,
            example = it.recommendedValue,
        )
    }

    suspend fun inspect(
        rawUrl: String,
        liveNetworkEnabled: Boolean,
        timeoutSeconds: Int,
    ): Result<SecurityHeadersAnalysisResult> {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter a full website URL (e.g. https://example.com)."))
        }

        val normalizedUrl = if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed
        } else {
            "https://$trimmed"
        }

        val parsedUri = try {
            URI(normalizedUrl)
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("Invalid URL syntax: ${e.localizedMessage ?: "cannot parse URL"}."))
        }

        val scheme = parsedUri.scheme?.lowercase()
        val host = parsedUri.host
        if (scheme !in listOf("http", "https") || host.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("URL must include a valid http:// or https:// scheme and hostname."))
        }

        if (!liveNetworkEnabled) {
            return Result.failure(
                IllegalStateException("Live HTTP header checks are disabled in Settings (Offline Mode). Enable Live Network Checks in Settings or browse the Header Reference Guide below."),
            )
        }

        return withContext(Dispatchers.IO) {
            try {
                val client = OkHttpClient.Builder()
                    .connectTimeout(timeoutSeconds.toLong(), TimeUnit.SECONDS)
                    .readTimeout(timeoutSeconds.toLong(), TimeUnit.SECONDS)
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .build()

                // Standard passive HEAD check first, falling back to GET if server returns 405
                val headReq = Request.Builder()
                    .url(normalizedUrl)
                    .head()
                    .header("User-Agent", "CyberForge-HeaderInspector/1.0")
                    .build()

                var response = client.newCall(headReq).execute()
                if (response.code == 405 || response.code == 501) {
                    response.close()
                    val getReq = Request.Builder()
                        .url(normalizedUrl)
                        .get()
                        .header("User-Agent", "CyberForge-HeaderInspector/1.0")
                        .build()
                    response = client.newCall(getReq).execute()
                }

                response.use { res ->
                    val responseHeaders = res.headers
                    val items = specs.map { spec ->
                        val values = responseHeaders.values(spec.name)
                        if (values.isNotEmpty()) {
                            SecurityHeaderAuditItem(
                                headerName = spec.name,
                                status = HeaderStatus.PRESENT,
                                observedValue = values.joinToString("; "),
                                importance = spec.importance,
                                purpose = spec.purpose,
                                missingRisk = spec.missingRisk,
                                recommendedValue = spec.recommendedValue,
                            )
                        } else {
                            SecurityHeaderAuditItem(
                                headerName = spec.name,
                                status = HeaderStatus.MISSING,
                                observedValue = null,
                                importance = spec.importance,
                                purpose = spec.purpose,
                                missingRisk = spec.missingRisk,
                                recommendedValue = spec.recommendedValue,
                            )
                        }
                    }

                    val presentCount = items.count { it.status == HeaderStatus.PRESENT }
                    val finalUrlString = res.request.url.toString()
                    val isHttps = res.request.url.isHttps

                    val note = if (!isHttps) {
                        "Warning: Final endpoint is unencrypted HTTP. HSTS is ignored by browsers over plaintext HTTP."
                    } else {
                        "Standard TLS verification enforced. Inspected live response headers without bypassing any security restrictions."
                    }

                    Result.success(
                        SecurityHeadersAnalysisResult(
                            requestedUrl = normalizedUrl,
                            finalUrl = finalUrlString,
                            httpStatusCode = res.code,
                            protocol = res.protocol.toString().uppercase(),
                            isHttps = isHttps,
                            presentCount = presentCount,
                            totalChecked = items.size,
                            headers = items,
                            note = note,
                        ),
                    )
                }
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("Could not retrieve headers: ${e.localizedMessage ?: e.javaClass.simpleName}. Verify connectivity, URL reachability, and valid TLS certificates."),
                )
            }
        }
    }
}
