package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.UiState
import com.example.engine.DnsLookupStatus
import com.example.engine.DomainAnalysisResult
import com.example.ui.components.EmptyTerminalCard
import com.example.ui.components.ErrorTerminalCard
import com.example.ui.components.KeyValueTerminalRow
import com.example.ui.components.LoadingTerminalCard
import com.example.ui.components.QuickSampleChipRow
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette

@Composable
fun DomainAnalyzerScreen(
    domainInput: String,
    state: UiState<DomainAnalysisResult>,
    onInputChange: (String) -> Unit,
    onAnalyze: (String?) -> Unit,
    onReset: () -> Unit,
) {
    val palette = LocalCyberPalette.current

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                SocTerminalCard(
                    terminalTag = "// DOMAIN_STRUCTURE_&_DNS_INSPECTOR",
                    accentColor = palette.secondaryAccent,
                ) {
                    Text(
                        text = "Domain & URL Analyzer",
                        style = MaterialTheme.typography.headlineSmall,
                        color = palette.textPrimary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Validates RFC 1123 syntax, decomposes protocol, hostname, root domain, and subdomains, and runs safe passive DNS resolution when Live Network Checks are enabled.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = domainInput,
                        onValueChange = onInputChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("domain_input_field"),
                        label = { Text("Domain name or URL (e.g. https://example.com)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Search,
                        ),
                        keyboardActions = KeyboardActions(onSearch = { onAnalyze(null) }),
                        leadingIcon = { Icon(Icons.Filled.Language, contentDescription = null) },
                        trailingIcon = {
                            if (domainInput.isNotEmpty()) {
                                IconButton(
                                    onClick = onReset,
                                    modifier = Modifier.testTag("domain_clear_button"),
                                ) {
                                    Icon(Icons.Outlined.Clear, contentDescription = "Clear domain input")
                                }
                            }
                        },
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    QuickSampleChipRow(
                        samples = listOf("https://example.com", "https://developer.android.com/docs", "http://test.local:8080/login"),
                        onSelect = { onAnalyze(it) },
                        tagPrefix = "domain",
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { onAnalyze(null) },
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("domain_analyze_button"),
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Validate & Inspect")
                        }
                        if (state !is UiState.Idle) {
                            OutlinedButton(
                                onClick = onReset,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("domain_reset_button"),
                            ) {
                                Text("Reset")
                            }
                        }
                    }
                }
            }

            when (state) {
                UiState.Idle -> {
                    item {
                        EmptyTerminalCard(
                            icon = Icons.Filled.Language,
                            title = "Enter a Domain or URL",
                            subtitle = "Inspect hostname formatting, transport scheme, IDN/Punycode flags, and non-invasive DNS A/AAAA resolution.",
                        )
                    }
                }

                UiState.Loading -> {
                    item {
                        LoadingTerminalCard(message = "Validating hostname and resolving DNS records...")
                    }
                }

                is UiState.Error -> {
                    item {
                        ErrorTerminalCard(message = state.message, hint = state.hint)
                    }
                }

                is UiState.Success -> {
                    val res = state.data
                    item {
                        SocTerminalCard(
                            terminalTag = "// PARSED_ENDPOINT_STRUCTURE",
                            accentColor = palette.primaryAccent,
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = res.hostname,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = palette.textPrimary,
                                    modifier = Modifier.weight(1f),
                                )
                                StatusBadge(
                                    label = res.protocol,
                                    color = if (res.protocol == "HTTP") palette.warn else palette.pass,
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = palette.border)
                            KeyValueTerminalRow("Root Domain", res.rootDomain)
                            KeyValueTerminalRow("Top-Level Domain (TLD)", res.tld)
                            KeyValueTerminalRow(
                                "Subdomains",
                                if (res.subdomainLabels.isEmpty()) "None (apex domain)" else res.subdomainLabels.joinToString("."),
                            )
                            KeyValueTerminalRow("Port", res.port?.toString() ?: "Default for scheme")
                            KeyValueTerminalRow("Path", res.path)
                        }
                    }

                    item {
                        SocTerminalCard(
                            terminalTag = "// SAFE_INFORMATIONAL_CHECKS",
                            accentColor = palette.secondaryAccent,
                        ) {
                            res.formatChecks.forEachIndexed { idx, check ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top,
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                        Text(
                                            text = check.label,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = palette.textPrimary,
                                        )
                                        Text(
                                            text = check.value,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = palette.textSecondary,
                                        )
                                    }
                                    StatusBadge(
                                        label = if (check.isWarning) "WARN" else "OK",
                                        color = if (check.isWarning) palette.warn else palette.pass,
                                    )
                                }
                                if (idx < res.formatChecks.lastIndex) {
                                    HorizontalDivider(color = palette.border)
                                }
                            }
                        }
                    }

                    item {
                        val dnsBadgeColor = when (res.dnsResult.status) {
                            DnsLookupStatus.RESOLVED -> palette.pass
                            DnsLookupStatus.FAILED -> palette.fail
                            DnsLookupStatus.DISABLED_OFFLINE_MODE -> palette.warn
                            DnsLookupStatus.NOT_APPLICABLE -> palette.info
                        }
                        SocTerminalCard(
                            terminalTag = "// LIVE_DNS_RESOLUTION",
                            accentColor = dnsBadgeColor,
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = "DNS A / AAAA Records",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary,
                                )
                                StatusBadge(
                                    label = res.dnsResult.status.name.replace("_", " "),
                                    color = dnsBadgeColor,
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = res.dnsResult.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                            )
                            if (res.dnsResult.resolvedAddresses.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                res.dnsResult.resolvedAddresses.forEach { ip ->
                                    Text(
                                        text = "→ $ip",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.primaryAccent,
                                        modifier = Modifier.padding(vertical = 2.dp),
                                    )
                                }
                            }
                        }
                    }

                    item {
                        SocTerminalCard(
                            terminalTag = "// UNAVAILABLE_OR_OUT_OF_SCOPE_CHECKS",
                            accentColor = palette.unavailable,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Lock,
                                    contentDescription = null,
                                    tint = palette.unavailable,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Checks Explicitly Not Performed",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary,
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            res.unavailableChecks.forEach { itemText ->
                                Text(
                                    text = "• [UNAVAILABLE] $itemText",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textMuted,
                                    modifier = Modifier.padding(vertical = 3.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
