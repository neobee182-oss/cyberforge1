package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.AccentTheme
import com.example.data.ScanConfig
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.LocalCyberPalette

@Composable
fun SettingsScreen(
    scanConfig: ScanConfig,
    historyCount: Int,
    onSelectTheme: (AccentTheme) -> Unit,
    onToggleLiveNetwork: (Boolean) -> Unit,
    onSelectTimeout: (Int) -> Unit,
    onToggleTerminalGrid: (Boolean) -> Unit,
    onToggleHighContrastBorders: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
) {
    val palette = LocalCyberPalette.current

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                SocTerminalCard(
                    terminalTag = "// THEME_&_SOC_APPEARANCE",
                    accentColor = palette.primaryAccent,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Palette,
                            contentDescription = null,
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SOC Accent Theme",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary,
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    AccentTheme.entries.forEach { theme ->
                        val selected = scanConfig.accentTheme == theme
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .minimumInteractiveComponentSize()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectTheme(theme) }
                                .testTag("theme_option_${theme.name.lowercase()}"),
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) palette.surfaceElevated else palette.background,
                            border = BorderStroke(
                                1.dp,
                                if (selected) palette.primaryAccent else palette.border,
                            ),
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = theme.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (selected) palette.primaryAccent else palette.textPrimary,
                                    )
                                    Text(
                                        text = theme.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                    )
                                }
                                Icon(
                                    imageVector = if (selected) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                    contentDescription = if (selected) "Selected" else "Select",
                                    tint = if (selected) palette.primaryAccent else palette.textMuted,
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = palette.border)
                    Spacer(modifier = Modifier.height(12.dp))

                    SettingSwitchRow(
                        title = "Terminal Grid Backdrop",
                        subtitle = "Render subtle tactical matrix grid lines behind SOC panels",
                        checked = scanConfig.showTerminalGrid,
                        onCheckedChange = onToggleTerminalGrid,
                        tag = "toggle_terminal_grid",
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingSwitchRow(
                        title = "High-Contrast Panel Borders",
                        subtitle = "Increase border brightness for outdoor or bright-room visibility",
                        checked = scanConfig.highContrastBorders,
                        onCheckedChange = onToggleHighContrastBorders,
                        tag = "toggle_high_contrast_borders",
                    )
                }
            }

            item {
                SocTerminalCard(
                    terminalTag = "// ACTIVE_SCAN_CONFIGURATIONS",
                    accentColor = palette.secondaryAccent,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = null,
                            tint = palette.secondaryAccent,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Diagnostic Engine Controls",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary,
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    SettingSwitchRow(
                        title = "Live Network Checks (DNS & HTTP Headers)",
                        subtitle = "When disabled, Domain & Headers analyzers run in strict offline validation mode",
                        checked = scanConfig.liveNetworkEnabled,
                        onCheckedChange = onToggleLiveNetwork,
                        tag = "toggle_live_network",
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Network Timeout Cap",
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 8, 12).forEach { seconds ->
                            FilterChip(
                                selected = scanConfig.timeoutSeconds == seconds,
                                onClick = { onSelectTimeout(seconds) },
                                label = { Text("${seconds}s") },
                                modifier = Modifier.testTag("timeout_chip_$seconds"),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = palette.border)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                            Text(
                                text = "Local Activity History ($historyCount)",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                            )
                            Text(
                                text = "Stores non-sensitive check summaries only. Passwords are never saved.",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                            )
                        }
                        OutlinedButton(
                            onClick = onClearHistory,
                            enabled = historyCount > 0,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("settings_clear_history_button"),
                        ) {
                            Icon(Icons.Outlined.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear")
                        }
                    }
                }
            }

            item {
                SocTerminalCard(
                    terminalTag = "// ABOUT_CYBERFORGE",
                    accentColor = palette.info,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Info,
                                contentDescription = null,
                                tint = palette.info,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CYBERFORGE.TECHNOLOGY",
                                style = MaterialTheme.typography.titleLarge,
                                color = palette.textPrimary,
                            )
                        }
                        StatusBadge(label = "v1.0.0", color = palette.info)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "CYBERFORGE is an educational and defensive cybersecurity workbench built for phones, foldables, and tablets. All password evaluations and IP validations execute locally on-device without third-party telemetry or paid APIs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary,
                    )
                }
            }

            item {
                SocTerminalCard(
                    terminalTag = "// AUTHORIZED_USE_DISCLAIMER",
                    accentColor = palette.warn,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Gavel,
                            contentDescription = null,
                            tint = palette.warn,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.disclaimer_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.warn,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.disclaimer_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary,
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String,
) {
    val palette = LocalCyberPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = palette.textPrimary,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag),
        )
    }
}
