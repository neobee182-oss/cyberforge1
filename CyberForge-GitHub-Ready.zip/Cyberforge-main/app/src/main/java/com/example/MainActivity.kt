package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.CyberForgeApp
import com.example.ui.theme.CyberForgeTheme
import com.example.viewmodel.CyberForgeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            val viewModel: CyberForgeViewModel = viewModel()
            val scanConfig by viewModel.scanConfig.collectAsStateWithLifecycle()

            CyberForgeTheme(
                accentTheme = scanConfig.accentTheme,
                highContrastBorders = scanConfig.highContrastBorders,
            ) {
                CyberForgeApp(viewModel = viewModel)
            }
        }
    }
}
