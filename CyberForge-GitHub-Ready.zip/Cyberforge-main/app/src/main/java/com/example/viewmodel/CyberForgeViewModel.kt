package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AccentTheme
import com.example.data.ActivityLogEntry
import com.example.data.ActivityStatus
import com.example.data.LearningRepository
import com.example.data.LessonTopic
import com.example.data.ScanConfig
import com.example.data.SecurityTip
import com.example.data.SettingsPreferencesRepository
import com.example.data.ToolCategory
import com.example.data.UiState
import com.example.engine.DnsLookupStatus
import com.example.engine.DomainAnalysisResult
import com.example.engine.DomainAnalyzer
import com.example.engine.IpAnalysisResult
import com.example.engine.IpAnalyzer
import com.example.engine.PasswordAnalysisResult
import com.example.engine.PasswordAnalyzer
import com.example.engine.SecurityHeadersAnalysisResult
import com.example.engine.SecurityHeadersAnalyzer
import com.example.engine.StrengthTier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CyberForgeViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = SettingsPreferencesRepository(application.applicationContext)

    val scanConfig: StateFlow<ScanConfig> = prefsRepo.scanConfigFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ScanConfig(),
    )

    val activityHistory: StateFlow<List<ActivityLogEntry>> = prefsRepo.activityLogFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList(),
    )

    // Dashboard tip carousel
    private val _tipIndex = MutableStateFlow(0)
    val tipIndex: StateFlow<Int> = _tipIndex.asStateFlow()

    val currentTip: SecurityTip
        get() = LearningRepository.securityTips[_tipIndex.value % LearningRepository.securityTips.size]

    fun nextSecurityTip() {
        _tipIndex.value = (_tipIndex.value + 1) % LearningRepository.securityTips.size
    }

    // Password Analyzer: strictly in-memory ephemeral state (never stored or transmitted)
    private val _passwordInput = MutableStateFlow("")
    val passwordInput: StateFlow<String> = _passwordInput.asStateFlow()

    private val _passwordAnalysis = MutableStateFlow<PasswordAnalysisResult?>(null)
    val passwordAnalysis: StateFlow<PasswordAnalysisResult?> = _passwordAnalysis.asStateFlow()

    fun onPasswordChanged(value: String) {
        _passwordInput.value = value
        _passwordAnalysis.value = if (value.isEmpty()) null else PasswordAnalyzer.analyze(value)
    }

    fun generateLocalSamplePassword() {
        val generated = PasswordAnalyzer.generateStrongPassword(18)
        onPasswordChanged(generated)
        logActivity(
            tool = ToolCategory.PASSWORD,
            summary = "Local CSPRNG password generated & audited",
            detail = "18 chars • In-memory only (not stored)",
            status = ActivityStatus.PASS,
        )
    }

    fun recordPasswordAuditSnapshot() {
        val result = _passwordAnalysis.value ?: return
        val status = when (result.tier) {
            StrengthTier.CRITICAL, StrengthTier.WEAK -> ActivityStatus.ERROR
            StrengthTier.MODERATE -> ActivityStatus.WARN
            StrengthTier.STRONG, StrengthTier.FORTIFIED -> ActivityStatus.PASS
        }
        // Only record tier & length—never the password itself!
        logActivity(
            tool = ToolCategory.PASSWORD,
            summary = "Local password audit (${result.tier.label})",
            detail = "Length ${result.length} • ${result.effectiveBits.toInt()} effective bits • Zero storage",
            status = status,
        )
    }

    fun wipePasswordMemory() {
        _passwordInput.value = ""
        _passwordAnalysis.value = null
    }

    // Domain Analyzer
    private val _domainInput = MutableStateFlow("")
    val domainInput: StateFlow<String> = _domainInput.asStateFlow()

    private val _domainState = MutableStateFlow<UiState<DomainAnalysisResult>>(UiState.Idle)
    val domainState: StateFlow<UiState<DomainAnalysisResult>> = _domainState.asStateFlow()

    fun onDomainInputChanged(value: String) {
        _domainInput.value = value
    }

    fun analyzeDomain(overrideInput: String? = null) {
        val target = overrideInput ?: _domainInput.value
        if (overrideInput != null) {
            _domainInput.value = overrideInput
        }
        val config = scanConfig.value
        viewModelScope.launch {
            _domainState.value = UiState.Loading
            val res = DomainAnalyzer.analyze(
                rawInput = target,
                liveNetworkEnabled = config.liveNetworkEnabled,
                timeoutSeconds = config.timeoutSeconds,
            )
            res.fold(
                onSuccess = { data ->
                    _domainState.value = UiState.Success(data)
                    val status = when (data.dnsResult.status) {
                        DnsLookupStatus.RESOLVED -> ActivityStatus.PASS
                        DnsLookupStatus.FAILED -> ActivityStatus.WARN
                        DnsLookupStatus.DISABLED_OFFLINE_MODE,
                        DnsLookupStatus.NOT_APPLICABLE -> ActivityStatus.INFO
                    }
                    logActivity(
                        tool = ToolCategory.DOMAIN,
                        summary = "Domain: ${data.hostname}",
                        detail = "${data.protocol} • ${data.dnsResult.note}",
                        status = status,
                    )
                },
                onFailure = { err ->
                    _domainState.value = UiState.Error(
                        message = err.message ?: "Invalid domain or URL.",
                        hint = "Example: https://example.com or sub.domain.org",
                    )
                },
            )
        }
    }

    fun resetDomainState() {
        _domainInput.value = ""
        _domainState.value = UiState.Idle
    }

    // Security Headers Analyzer
    private val _headersUrlInput = MutableStateFlow("")
    val headersUrlInput: StateFlow<String> = _headersUrlInput.asStateFlow()

    private val _headersState = MutableStateFlow<UiState<SecurityHeadersAnalysisResult>>(UiState.Idle)
    val headersState: StateFlow<UiState<SecurityHeadersAnalysisResult>> = _headersState.asStateFlow()

    fun onHeadersUrlChanged(value: String) {
        _headersUrlInput.value = value
    }

    fun inspectSecurityHeaders(overrideUrl: String? = null) {
        val target = overrideUrl ?: _headersUrlInput.value
        if (overrideUrl != null) {
            _headersUrlInput.value = overrideUrl
        }
        val config = scanConfig.value
        viewModelScope.launch {
            _headersState.value = UiState.Loading
            val res = SecurityHeadersAnalyzer.inspect(
                rawUrl = target,
                liveNetworkEnabled = config.liveNetworkEnabled,
                timeoutSeconds = config.timeoutSeconds,
            )
            res.fold(
                onSuccess = { data ->
                    _headersState.value = UiState.Success(data)
                    val status = when {
                        data.presentCount >= 6 && data.isHttps -> ActivityStatus.PASS
                        data.presentCount >= 3 -> ActivityStatus.WARN
                        else -> ActivityStatus.ERROR
                    }
                    logActivity(
                        tool = ToolCategory.HEADERS,
                        summary = "Headers: ${data.finalUrl}",
                        detail = "HTTP ${data.httpStatusCode} • ${data.presentCount}/${data.totalChecked} headers present",
                        status = status,
                    )
                },
                onFailure = { err ->
                    val msg = err.message ?: "Unable to fetch security headers."
                    _headersState.value = UiState.Error(
                        message = msg,
                        hint = "Check URL syntax, internet access, or Settings → Live Network Checks.",
                    )
                    logActivity(
                        tool = ToolCategory.HEADERS,
                        summary = "Header check unavailable",
                        detail = target.trim().ifEmpty { "Empty URL" } + " • " + msg.take(70),
                        status = ActivityStatus.ERROR,
                    )
                },
            )
        }
    }

    fun resetHeadersState() {
        _headersUrlInput.value = ""
        _headersState.value = UiState.Idle
    }

    // IP Analyzer
    private val _ipInput = MutableStateFlow("")
    val ipInput: StateFlow<String> = _ipInput.asStateFlow()

    private val _ipState = MutableStateFlow<UiState<IpAnalysisResult>>(UiState.Idle)
    val ipState: StateFlow<UiState<IpAnalysisResult>> = _ipState.asStateFlow()

    fun onIpInputChanged(value: String) {
        _ipInput.value = value
    }

    fun analyzeIp(overrideIp: String? = null) {
        val target = overrideIp ?: _ipInput.value
        if (overrideIp != null) {
            _ipInput.value = overrideIp
        }
        val res = IpAnalyzer.analyze(target)
        res.fold(
            onSuccess = { data ->
                _ipState.value = UiState.Success(data)
                logActivity(
                    tool = ToolCategory.IP,
                    summary = "IP: ${data.canonicalAddress}",
                    detail = "${data.version.label} • ${data.classification}",
                    status = ActivityStatus.INFO,
                )
            },
            onFailure = { err ->
                _ipState.value = UiState.Error(
                    message = err.message ?: "Invalid IP address format.",
                    hint = "Examples: 192.168.1.10, 8.8.8.8, ::1, 2001:db8::1",
                )
            },
        )
    }

    fun resetIpState() {
        _ipInput.value = ""
        _ipState.value = UiState.Idle
    }

    // Learning Center
    private val _selectedTopic = MutableStateFlow<LessonTopic?>(null)
    val selectedTopic: StateFlow<LessonTopic?> = _selectedTopic.asStateFlow()

    private val _completedLessonIds = MutableStateFlow<Set<String>>(emptySet())
    val completedLessonIds: StateFlow<Set<String>> = _completedLessonIds.asStateFlow()

    fun selectLessonTopic(topic: LessonTopic?) {
        _selectedTopic.value = topic
    }

    fun markLessonCompleted(lessonId: String) {
        _completedLessonIds.value = _completedLessonIds.value + lessonId
    }

    // Settings Actions
    fun setAccentTheme(theme: AccentTheme) {
        viewModelScope.launch { prefsRepo.updateAccentTheme(theme) }
    }

    fun setLiveNetworkEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.updateLiveNetworkEnabled(enabled) }
    }

    fun setTimeoutSeconds(seconds: Int) {
        viewModelScope.launch { prefsRepo.updateTimeoutSeconds(seconds) }
    }

    fun setShowTerminalGrid(show: Boolean) {
        viewModelScope.launch { prefsRepo.updateShowTerminalGrid(show) }
    }

    fun setHighContrastBorders(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.updateHighContrastBorders(enabled) }
    }

    fun clearActivityHistory() {
        viewModelScope.launch { prefsRepo.clearActivityHistory() }
    }

    private fun logActivity(
        tool: ToolCategory,
        summary: String,
        detail: String,
        status: ActivityStatus,
    ) {
        viewModelScope.launch {
            prefsRepo.appendActivity(
                ActivityLogEntry(
                    id = System.currentTimeMillis(),
                    tool = tool,
                    summary = summary,
                    detail = detail,
                    status = status,
                    timestampMillis = System.currentTimeMillis(),
                ),
            )
        }
    }
}
