package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Http
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.StatusBadge
import com.example.ui.components.TerminalGridBackground
import com.example.ui.screens.CyberRoute
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DomainAnalyzerScreen
import com.example.ui.screens.IpInfoScreen
import com.example.ui.screens.LearningCenterScreen
import com.example.ui.screens.PasswordAnalyzerScreen
import com.example.ui.screens.SecurityHeadersScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalCyberPalette
import com.example.viewmodel.CyberForgeViewModel
import kotlinx.coroutines.launch

private data class NavDestinationSpec(
    val route: CyberRoute,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val showInBottomBar: Boolean,
)

private val navDestinations = listOf(
    NavDestinationSpec(CyberRoute.DASHBOARD, Icons.Filled.Dashboard, Icons.Outlined.Dashboard, true),
    NavDestinationSpec(CyberRoute.PASSWORD, Icons.Filled.Key, Icons.Outlined.Key, true),
    NavDestinationSpec(CyberRoute.DOMAIN, Icons.Filled.Language, Icons.Outlined.Language, true),
    NavDestinationSpec(CyberRoute.HEADERS, Icons.Filled.Http, Icons.Outlined.Http, true),
    NavDestinationSpec(CyberRoute.IP_INFO, Icons.Filled.Dns, Icons.Outlined.Dns, false),
    NavDestinationSpec(CyberRoute.LEARN, Icons.Filled.School, Icons.Outlined.School, true),
    NavDestinationSpec(CyberRoute.SETTINGS, Icons.Filled.Settings, Icons.Outlined.Settings, false),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberForgeApp(viewModel: CyberForgeViewModel) {
    val palette = LocalCyberPalette.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRouteString = backStackEntry?.destination?.route ?: CyberRoute.DASHBOARD.route
    val currentRoute = CyberRoute.entries.firstOrNull { it.route == currentRouteString } ?: CyberRoute.DASHBOARD

    val scanConfig by viewModel.scanConfig.collectAsStateWithLifecycle()
    val activityHistory by viewModel.activityHistory.collectAsStateWithLifecycle()
    val tipIndex by viewModel.tipIndex.collectAsStateWithLifecycle()
    val passwordInput by viewModel.passwordInput.collectAsStateWithLifecycle()
    val passwordAnalysis by viewModel.passwordAnalysis.collectAsStateWithLifecycle()
    val domainInput by viewModel.domainInput.collectAsStateWithLifecycle()
    val domainState by viewModel.domainState.collectAsStateWithLifecycle()
    val headersUrlInput by viewModel.headersUrlInput.collectAsStateWithLifecycle()
    val headersState by viewModel.headersState.collectAsStateWithLifecycle()
    val ipInput by viewModel.ipInput.collectAsStateWithLifecycle()
    val ipState by viewModel.ipState.collectAsStateWithLifecycle()
    val selectedTopic by viewModel.selectedTopic.collectAsStateWithLifecycle()
    val completedLessons by viewModel.completedLessonIds.collectAsStateWithLifecycle()

    val navigateTo: (CyberRoute) -> Unit = { target ->
        navController.navigate(target.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        val mainContent: @Composable () -> Unit = {
            TerminalGridBackground(enabled = scanConfig.showTerminalGrid) {
                Row(modifier = Modifier.fillMaxSize()) {
                    if (isWideScreen) {
                        // Permanent SOC Sidebar NavigationRail on Tablet / Desktop
                        NavigationRail(
                            modifier = Modifier
                                .fillMaxHeight()
                                .windowInsetsPadding(WindowInsets.safeDrawing),
                            containerColor = palette.surface,
                            contentColor = palette.textPrimary,
                            header = {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(vertical = 12.dp),
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = palette.primaryAccent.copy(alpha = 0.14f),
                                        border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.45f)),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Shield,
                                            contentDescription = "CYBERFORGE",
                                            tint = palette.primaryAccent,
                                            modifier = Modifier
                                                .padding(10.dp)
                                                .size(24.dp),
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "FORGE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.primaryAccent,
                                    )
                                }
                            },
                        ) {
                            Column(
                                modifier = Modifier.verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                navDestinations.forEach { dest ->
                                    val selected = currentRoute == dest.route
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { navigateTo(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.route.label,
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = dest.route.label,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        },
                                        modifier = Modifier.testTag("rail_${dest.route.route}"),
                                    )
                                }
                            }
                        }
                    }

                    Scaffold(
                        modifier = Modifier.weight(1f),
                        containerColor = Color.Transparent,
                        contentWindowInsets = WindowInsets.safeDrawing,
                        topBar = {
                            TopAppBar(
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = palette.surface.copy(alpha = 0.94f),
                                    titleContentColor = palette.textPrimary,
                                ),
                                navigationIcon = {
                                    if (!isWideScreen) {
                                        IconButton(
                                            onClick = { scope.launch { drawerState.open() } },
                                            modifier = Modifier.testTag("open_menu_drawer_button"),
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Menu,
                                                contentDescription = "Open navigation menu",
                                                tint = palette.primaryAccent,
                                            )
                                        }
                                    }
                                },
                                title = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Text(
                                            text = if (currentRoute == CyberRoute.DASHBOARD) {
                                                "CYBERFORGE"
                                            } else {
                                                currentRoute.label.uppercase()
                                            },
                                            style = MaterialTheme.typography.titleLarge,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        StatusBadge(
                                            label = if (scanConfig.liveNetworkEnabled) "PASSIVE" else "OFFLINE",
                                            color = if (scanConfig.liveNetworkEnabled) palette.primaryAccent else palette.warn,
                                        )
                                    }
                                },
                                actions = {
                                    IconButton(
                                        onClick = { navigateTo(CyberRoute.IP_INFO) },
                                        modifier = Modifier.testTag("topbar_ip_button"),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Dns,
                                            contentDescription = "IP Information",
                                            tint = if (currentRoute == CyberRoute.IP_INFO) palette.primaryAccent else palette.textSecondary,
                                        )
                                    }
                                    IconButton(
                                        onClick = { navigateTo(CyberRoute.SETTINGS) },
                                        modifier = Modifier.testTag("topbar_settings_button"),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Settings,
                                            contentDescription = "Settings",
                                            tint = if (currentRoute == CyberRoute.SETTINGS) palette.primaryAccent else palette.textSecondary,
                                        )
                                    }
                                },
                            )
                        },
                        bottomBar = {
                            if (!isWideScreen) {
                                NavigationBar(
                                    containerColor = palette.surface,
                                    contentColor = palette.textPrimary,
                                    windowInsets = WindowInsets.navigationBars,
                                ) {
                                    navDestinations.filter { it.showInBottomBar }.forEach { dest ->
                                        val selected = currentRoute == dest.route
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = { navigateTo(dest.route) },
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                    contentDescription = dest.route.label,
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = dest.route.label,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            },
                                            modifier = Modifier.testTag("bottom_${dest.route.route}"),
                                        )
                                    }
                                }
                            }
                        },
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = CyberRoute.DASHBOARD.route,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                        ) {
                            composable(CyberRoute.DASHBOARD.route) {
                                val tip = com.example.data.LearningRepository.securityTips[
                                    tipIndex % com.example.data.LearningRepository.securityTips.size
                                ]
                                DashboardScreen(
                                    scanConfig = scanConfig,
                                    activityHistory = activityHistory,
                                    currentTip = tip,
                                    isWideScreen = isWideScreen,
                                    onNavigate = navigateTo,
                                    onNextTip = viewModel::nextSecurityTip,
                                    onClearHistory = viewModel::clearActivityHistory,
                                )
                            }
                            composable(CyberRoute.PASSWORD.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                PasswordAnalyzerScreen(
                                    passwordInput = passwordInput,
                                    analysis = passwordAnalysis,
                                    onPasswordChange = viewModel::onPasswordChanged,
                                    onGenerateStrong = viewModel::generateLocalSamplePassword,
                                    onWipeMemory = viewModel::wipePasswordMemory,
                                    onRecordSnapshot = viewModel::recordPasswordAuditSnapshot,
                                )
                            }
                            composable(CyberRoute.DOMAIN.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                DomainAnalyzerScreen(
                                    domainInput = domainInput,
                                    state = domainState,
                                    onInputChange = viewModel::onDomainInputChanged,
                                    onAnalyze = viewModel::analyzeDomain,
                                    onReset = viewModel::resetDomainState,
                                )
                            }
                            composable(CyberRoute.HEADERS.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                SecurityHeadersScreen(
                                    urlInput = headersUrlInput,
                                    state = headersState,
                                    onUrlChange = viewModel::onHeadersUrlChanged,
                                    onInspect = viewModel::inspectSecurityHeaders,
                                    onReset = viewModel::resetHeadersState,
                                )
                            }
                            composable(CyberRoute.IP_INFO.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                IpInfoScreen(
                                    ipInput = ipInput,
                                    state = ipState,
                                    onInputChange = viewModel::onIpInputChanged,
                                    onAnalyze = viewModel::analyzeIp,
                                    onReset = viewModel::resetIpState,
                                )
                            }
                            composable(CyberRoute.LEARN.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                LearningCenterScreen(
                                    selectedTopic = selectedTopic,
                                    completedLessonIds = completedLessons,
                                    isWideScreen = isWideScreen,
                                    onSelectTopic = viewModel::selectLessonTopic,
                                    onMarkCompleted = viewModel::markLessonCompleted,
                                )
                            }
                            composable(CyberRoute.SETTINGS.route) {
                                BackHandler { navigateTo(CyberRoute.DASHBOARD) }
                                SettingsScreen(
                                    scanConfig = scanConfig,
                                    historyCount = activityHistory.size,
                                    onSelectTheme = viewModel::setAccentTheme,
                                    onToggleLiveNetwork = viewModel::setLiveNetworkEnabled,
                                    onSelectTimeout = viewModel::setTimeoutSeconds,
                                    onToggleTerminalGrid = viewModel::setShowTerminalGrid,
                                    onToggleHighContrastBorders = viewModel::setHighContrastBorders,
                                    onClearHistory = viewModel::clearActivityHistory,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (!isWideScreen) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = palette.surface,
                        drawerContentColor = palette.textPrimary,
                        modifier = Modifier.width(290.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 8.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = null,
                                    tint = palette.primaryAccent,
                                    modifier = Modifier.size(26.dp),
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "CYBERFORGE",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = palette.textPrimary,
                                    )
                                    Text(
                                        text = "SOC WORKBENCH",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.primaryAccent,
                                    )
                                }
                            }
                            HorizontalDivider(
                                color = palette.border,
                                modifier = Modifier.padding(vertical = 12.dp),
                            )
                            navDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationDrawerItem(
                                    label = { Text(dest.route.label) },
                                    selected = selected,
                                    onClick = {
                                        scope.launch { drawerState.close() }
                                        navigateTo(dest.route)
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = null,
                                        )
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        selectedContainerColor = palette.primaryAccent.copy(alpha = 0.16f),
                                        selectedIconColor = palette.primaryAccent,
                                        selectedTextColor = palette.primaryAccent,
                                        unselectedContainerColor = Color.Transparent,
                                        unselectedIconColor = palette.textSecondary,
                                        unselectedTextColor = palette.textPrimary,
                                    ),
                                    modifier = Modifier
                                        .padding(vertical = 2.dp)
                                        .testTag("drawer_${dest.route.route}"),
                                )
                            }
                        }
                    }
                },
                content = mainContent,
            )
        } else {
            mainContent()
        }
    }
}
