package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ClearAll
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.engine.PasswordAnalysisResult
import com.example.engine.PatternSeverity
import com.example.engine.StrengthTier
import com.example.ui.components.EmptyTerminalCard
import com.example.ui.components.KeyValueTerminalRow
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette
import kotlin.math.roundToInt

@Composable
fun PasswordAnalyzerScreen(
    passwordInput: String,
    analysis: PasswordAnalysisResult?,
    onPasswordChange: (String) -> Unit,
    onGenerateStrong: () -> Unit,
    onWipeMemory: () -> Unit,
    onRecordSnapshot: () -> Unit,
) {
    val palette = LocalCyberPalette.current
    val clipboard = LocalClipboardManager.current
    var showPlaintext by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                SocTerminalCard(
                    terminalTag = "// PASSWORD_ENTROPY_ANALYZER",
                    accentColor = palette.primaryAccent,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = "Local Password Strength Audit",
                                style = MaterialTheme.typography.headlineSmall,
                                color = palette.textPrimary,
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Evaluated strictly in-memory on this device. Passwords are never stored, logged, or transmitted over the network.",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                            )
                        }
                        StatusBadge(label = "LOCAL ONLY", color = palette.primaryAccent)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = onPasswordChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input_field"),
                        label = { Text("Enter password or passphrase to audit") },
                        singleLine = true,
                        visualTransformation = if (showPlaintext) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        leadingIcon = {
                            Icon(Icons.Outlined.Lock, contentDescription = null)
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { showPlaintext = !showPlaintext },
                                modifier = Modifier.testTag("password_visibility_toggle"),
                            ) {
                                Icon(
                                    imageVector = if (showPlaintext) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (showPlaintext) "Hide password" else "Show password",
                                )
                            }
                        },
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = onGenerateStrong,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("generate_password_button"),
                        ) {
                            Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate Strong")
                        }
                        OutlinedButton(
                            onClick = {
                                if (passwordInput.isNotEmpty()) {
                                    clipboard.setText(AnnotatedString(passwordInput))
                                }
                            },
                            enabled = passwordInput.isNotEmpty(),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("copy_password_button"),
                        ) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy password", modifier = Modifier.size(18.dp))
                        }
                        OutlinedButton(
                            onClick = onWipeMemory,
                            enabled = passwordInput.isNotEmpty(),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("wipe_password_button"),
                        ) {
                            Icon(Icons.Outlined.ClearAll, contentDescription = "Wipe memory", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            if (analysis == null) {
                item {
                    EmptyTerminalCard(
                        icon = Icons.Filled.Key,
                        title = "Awaiting Credential Input",
                        subtitle = "Type any candidate password above or tap 'Generate Strong' to inspect Shannon entropy, character diversity, and weak pattern heuristics.",
                    )
                }
            } else {
                item {
                    val meterColor by animateColorAsState(
                        targetValue = when (analysis.tier) {
                            StrengthTier.CRITICAL, StrengthTier.WEAK -> palette.fail
                            StrengthTier.MODERATE -> palette.warn
                            StrengthTier.STRONG -> palette.secondaryAccent
                            StrengthTier.FORTIFIED -> palette.pass
                        },
                        animationSpec = tween(250),
                        label = "strength_color",
                    )
                    val meterFraction by animateFloatAsState(
                        targetValue = analysis.tier.fraction,
                        animationSpec = tween(300),
                        label = "strength_fraction",
                    )

                    SocTerminalCard(
                        terminalTag = "// STRENGTH_METER_AND_ENTROPY",
                        accentColor = meterColor,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column {
                                Text(
                                    text = "Estimated Strength",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.textMuted,
                                )
                                Text(
                                    text = analysis.tier.label.uppercase(),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = meterColor,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${analysis.effectiveBits.roundToInt()} bits",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = palette.textPrimary,
                                )
                                Text(
                                    text = "Effective Entropy",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textMuted,
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(14.dp),
                        ) {
                            drawRoundRect(
                                color = palette.surfaceElevated,
                                size = Size(size.width, size.height),
                                cornerRadius = CornerRadius(7.dp.toPx(), 7.dp.toPx()),
                            )
                            drawRoundRect(
                                color = meterColor,
                                size = Size(size.width * meterFraction, size.height),
                                cornerRadius = CornerRadius(7.dp.toPx(), 7.dp.toPx()),
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            ClassChip("a-z", analysis.hasLowercase, Modifier.weight(1f))
                            ClassChip("A-Z", analysis.hasUppercase, Modifier.weight(1f))
                            ClassChip("0-9", analysis.hasDigits, Modifier.weight(1f))
                            ClassChip("!@#", analysis.hasSymbols, Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = palette.border)
                        KeyValueTerminalRow(
                            key = "Estimated Offline Resistance (GPU Benchmark)",
                            value = analysis.estimatedCrackTime,
                            valueColor = meterColor,
                        )
                        KeyValueTerminalRow(
                            key = "Metrics",
                            value = "Length: ${analysis.length} | Unique: ${analysis.uniqueChars} | Pool: ${analysis.poolSize} | Raw: ${analysis.entropyBits.roundToInt()} bits",
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onRecordSnapshot,
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("log_password_audit_summary_button"),
                        ) {
                            Icon(Icons.Outlined.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Anonymized Audit Summary to Activity")
                        }
                    }
                }

                item {
                    SocTerminalCard(
                        terminalTag = "// WEAK_PATTERN_INSPECTION",
                        accentColor = palette.warn,
                    ) {
                        Text(
                            text = "Pattern & Heuristic Findings (${analysis.findings.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        analysis.findings.forEachIndexed { idx, finding ->
                            val sevColor = when (finding.severity) {
                                PatternSeverity.HIGH -> palette.fail
                                PatternSeverity.MEDIUM -> palette.warn
                                PatternSeverity.INFO -> palette.pass
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top,
                            ) {
                                Icon(
                                    imageVector = if (finding.severity == PatternSeverity.INFO) {
                                        Icons.Outlined.CheckCircle
                                    } else {
                                        Icons.Outlined.WarningAmber
                                    },
                                    contentDescription = null,
                                    tint = sevColor,
                                    modifier = Modifier.size(20.dp),
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = finding.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = sevColor,
                                    )
                                    Text(
                                        text = finding.detail,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                    )
                                }
                            }
                            if (idx < analysis.findings.lastIndex) {
                                HorizontalDivider(color = palette.border, modifier = Modifier.padding(vertical = 8.dp))
                            }
                        }

                        if (analysis.recommendations.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(color = palette.border)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "HARDENING RECOMMENDATIONS",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.secondaryAccent,
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            analysis.recommendations.forEach { rec ->
                                Text(
                                    text = "• $rec",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    modifier = Modifier.padding(vertical = 2.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun ClassChip(
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    val color = if (active) palette.pass else palette.textMuted
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = if (active) palette.pass.copy(alpha = 0.14f) else palette.surfaceElevated,
        border = BorderStroke(1.dp, if (active) palette.pass.copy(alpha = 0.5f) else palette.border),
    ) {
        Text(
            text = if (active) "✓ $label" else "× $label",
            style = MaterialTheme.typography.labelMedium,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
        )
    }
}
