package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ActivityLogEntry
import com.example.data.ActivityStatus
import com.example.data.ToolCategory
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette

@Composable
fun TerminalGridBackground(
    enabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val palette = LocalCyberPalette.current
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.background)
            .drawBehind {
                if (!enabled) return@drawBehind
                val step = 32.dp.toPx()
                val lineColor = palette.primaryAccent.copy(alpha = 0.045f)
                var x = 0f
                while (x <= size.width) {
                    drawLine(
                        color = lineColor,
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f,
                    )
                    x += step
                }
                var y = 0f
                while (y <= size.height) {
                    drawLine(
                        color = lineColor,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f,
                    )
                    y += step
                }
            },
    ) {
        content()
    }
}

@Composable
fun SocTerminalCard(
    modifier: Modifier = Modifier,
    terminalTag: String? = null,
    accentColor: Color = LocalCyberPalette.current.primaryAccent,
    content: @Composable ColumnScope.() -> Unit,
) {
    val palette = LocalCyberPalette.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = palette.surface.copy(alpha = 0.94f),
        border = BorderStroke(1.dp, palette.border),
        tonalElevation = 2.dp,
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (terminalTag != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(accentColor),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = terminalTag,
                        style = MaterialTheme.typography.labelMedium,
                        color = accentColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                HorizontalDivider(
                    color = palette.border,
                    thickness = 1.dp,
                    modifier = Modifier.padding(bottom = 12.dp),
                )
            }
            content()
        }
    }
}

@Composable
fun StatusBadge(
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            maxLines = 1,
        )
    }
}

@Composable
fun KeyValueTerminalRow(
    key: String,
    value: String,
    valueColor: Color = LocalCyberPalette.current.textPrimary,
) {
    val palette = LocalCyberPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
    ) {
        Text(
            text = key.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = palette.textMuted,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontFamily = JetBrainsMonoFontFamily,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor,
        )
    }
}

@Composable
fun LoadingTerminalCard(
    message: String,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    SocTerminalCard(
        modifier = modifier,
        terminalTag = "// EXECUTING_PASSIVE_CHECK",
        accentColor = palette.secondaryAccent,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(vertical = 8.dp),
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = palette.secondaryAccent,
                strokeWidth = 2.5.dp,
            )
            Column {
                Text(
                    text = message,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Enforcing standard timeout and passive-only rules...",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
            }
        }
    }
}

@Composable
fun ErrorTerminalCard(
    message: String,
    hint: String? = null,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    SocTerminalCard(
        modifier = modifier,
        terminalTag = "// CHECK_REJECTED_OR_UNAVAILABLE",
        accentColor = palette.fail,
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = Icons.Outlined.ErrorOutline,
                contentDescription = "Error",
                tint = palette.fail,
                modifier = Modifier.size(22.dp),
            )
            Column {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textPrimary,
                )
                if (!hint.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = hint,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyTerminalCard(
    icon: ImageVector = Icons.Outlined.Terminal,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    SocTerminalCard(
        modifier = modifier,
        terminalTag = "// READY_FOR_INPUT",
        accentColor = palette.textMuted,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.padding(vertical = 6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.surfaceElevated)
                    .border(1.dp, palette.border, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = palette.secondaryAccent,
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
            }
        }
    }
}

@Composable
fun QuickSampleChipRow(
    samples: List<String>,
    onSelect: (String) -> Unit,
    tagPrefix: String,
) {
    val palette = LocalCyberPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        samples.forEachIndexed { index, sample ->
            Surface(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(sample) }
                    .testTag("${tagPrefix}_sample_$index"),
                shape = RoundedCornerShape(10.dp),
                color = palette.surfaceElevated,
                border = BorderStroke(1.dp, palette.border),
            ) {
                Text(
                    text = sample,
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.secondaryAccent,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                )
            }
        }
    }
}

@Composable
fun ActivityTelemetryChart(
    entries: List<ActivityLogEntry>,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    val counts = ToolCategory.entries.map { category ->
        category to entries.count { it.tool == category }
    }
    val maxCount = (counts.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val total = entries.size

    val passCount = entries.count { it.status == ActivityStatus.PASS }
    val warnCount = entries.count { it.status == ActivityStatus.WARN }
    val infoCount = entries.count { it.status == ActivityStatus.INFO }
    val errCount = entries.count { it.status == ActivityStatus.ERROR }

    SocTerminalCard(
        modifier = modifier,
        terminalTag = "// TELEMETRY_DISTRIBUTION",
        accentColor = palette.secondaryAccent,
    ) {
        if (entries.isEmpty()) {
            Text(
                text = "No real diagnostic events recorded yet.",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Charts populate strictly from checks you execute. Run a Password, Domain, Header, or IP check to visualize activity.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Executions by Module",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                )
                StatusBadge(
                    label = "$total TOTAL",
                    color = palette.secondaryAccent,
                )
            }
            Spacer(modifier = Modifier.height(14.dp))

            counts.forEach { (category, count) ->
                val targetFraction = count.toFloat() / maxCount.toFloat()
                val animatedFraction by animateFloatAsState(
                    targetValue = targetFraction,
                    animationSpec = tween(durationMillis = 350),
                    label = "bar_${category.name}",
                )
                val barColor = when (category) {
                    ToolCategory.PASSWORD -> palette.primaryAccent
                    ToolCategory.DOMAIN -> palette.secondaryAccent
                    ToolCategory.HEADERS -> palette.warn
                    ToolCategory.IP -> palette.info
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                ) {
                    Text(
                        text = category.displayName,
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textSecondary,
                        modifier = Modifier.width(78.dp),
                    )
                    Canvas(
                        modifier = Modifier
                            .weight(1f)
                            .height(12.dp),
                    ) {
                        drawRoundRect(
                            color = palette.surfaceElevated,
                            size = Size(size.width, size.height),
                            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                        )
                        if (animatedFraction > 0f) {
                            drawRoundRect(
                                color = barColor,
                                size = Size((size.width * animatedFraction).coerceAtLeast(10.dp.toPx()), size.height),
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = count.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = palette.border)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StatusBadge(label = "PASS $passCount", color = palette.pass)
                StatusBadge(label = "INFO $infoCount", color = palette.info)
                StatusBadge(label = "WARN $warnCount", color = palette.warn)
                StatusBadge(label = "ERR $errCount", color = palette.fail)
            }
        }
    }
}
