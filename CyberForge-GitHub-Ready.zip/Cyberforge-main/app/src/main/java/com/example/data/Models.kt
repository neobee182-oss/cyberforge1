package com.example.data

enum class AccentTheme(val label: String, val subtitle: String) {
    CYBER_MATRIX("Cyber Matrix", "Neon Green & Electric Cyan"),
    COBALT_SENTINEL("Cobalt Sentinel", "Electric Cyan & Sky Pulse"),
    STEALTH_AMBER("Stealth Amber", "Tactical Amber & Cyan"),
}

enum class ToolCategory(val displayName: String) {
    PASSWORD("Password"),
    DOMAIN("Domain"),
    HEADERS("Headers"),
    IP("IP Info"),
}

enum class ActivityStatus {
    PASS,
    WARN,
    INFO,
    ERROR,
}

data class ActivityLogEntry(
    val id: Long,
    val tool: ToolCategory,
    val summary: String,
    val detail: String,
    val status: ActivityStatus,
    val timestampMillis: Long,
)

data class ScanConfig(
    val liveNetworkEnabled: Boolean = true,
    val timeoutSeconds: Int = 8,
    val showTerminalGrid: Boolean = true,
    val highContrastBorders: Boolean = false,
    val accentTheme: AccentTheme = AccentTheme.CYBER_MATRIX,
)

data class SecurityTip(
    val id: String,
    val category: String,
    val title: String,
    val summary: String,
)

sealed interface UiState<out T> {
    data object Idle : UiState<Nothing>
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String, val hint: String? = null) : UiState<Nothing>
}
