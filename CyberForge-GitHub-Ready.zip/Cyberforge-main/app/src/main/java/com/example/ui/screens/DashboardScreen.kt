package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ActivityLogEntry
import com.example.data.ActivityStatus
import com.example.data.ScanConfig
import com.example.data.SecurityTip
import com.example.ui.components.ActivityTelemetryChart
import com.example.ui.components.EmptyTerminalCard
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.LocalCyberPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CyberRoute(val route: String, val label: String) {
    DASHBOARD("dashboard", "Dashboard"),
    PASSWORD("password", "Password"),
    DOMAIN("domain", "Domain"),
    HEADERS("headers", "Headers"),
    IP_INFO("ip_info", "IP Info"),
    LEARN("learn", "Learn"),
    SETTINGS("settings", "Settings"),
}

@Composable
fun DashboardScreen(
    scanConfig: ScanConfig,
    activityHistory: List<ActivityLogEntry>,
    currentTip: SecurityTip,
    isWideScreen: Boolean,
    onNavigate: (CyberRoute) -> Unit,
    onNextTip: () -> Unit,
    onClearHistory: () -> Unit,
) {
    val palette = LocalCyberPalette.current

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 1040.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                // Hero SOC Welcome Banner
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = palette.surface,
                    border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_soc_banner),
                            contentDescription = "CYBERFORGE SOC operations banner",
                            contentScale = ContentScale.Crop,
                            alpha = 0.45f,
                            modifier = Modifier.matchParentSize(),
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            palette.background.copy(alpha = 0.94f),
                                            palette.background.copy(alpha = 0.72f),
                                        ),
                                    ),
                                ),
                        )
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                StatusBadge(
                                    label = if (scanConfig.liveNetworkEnabled) "PASSIVE ENGINE • LIVE TLS/DNS" else "STRICT OFFLINE MODE",
                                    color = if (scanConfig.liveNetworkEnabled) palette.primaryAccent else palette.warn,
                                )
                                StatusBadge(
                                    label = "ZERO STORAGE SECRETS",
                                    color = palette.secondaryAccent,
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "CYBERFORGE.TECHNOLOGY",
                                style = MaterialTheme.typography.headlineMedium,
                                color = palette.textPrimary,
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Defensive Security Operations Workbench for local password entropy auditing, domain validation, HTTP security header inspection, IP classification, and security training.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary,
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                FilledTonalButton(
                                    onClick = { onNavigate(CyberRoute.HEADERS) },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("hero_inspect_headers_button"),
                                ) {
                                    Icon(Icons.Filled.Http, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Inspect Headers")
                                }
                                OutlinedButton(
                                    onClick = { onNavigate(CyberRoute.PASSWORD) },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("hero_audit_password_button"),
                                ) {
                                    Icon(Icons.Filled.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Audit Password")
                                }
                            }
                        }
                    }
                }
            }

            item {
                // Active Scan Configurations Card
                SocTerminalCard(
                    terminalTag = "// ACTIVE_SCAN_CONFIGURATIONS",
                    accentColor = palette.primaryAccent,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Engine Safeguards & Policy",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary,
                            )
                            Text(
                                text = "Configured in Settings • Enforced across all tools",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                            )
                        }
                        IconButton(
                            onClick = { onNavigate(CyberRoute.SETTINGS) },
                            modifier = Modifier.testTag("dashboard_config_settings_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Tune,
                                contentDescription = "Configure scan settings",
                                tint = palette.primaryAccent,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    ConfigStatRow(
                        label = "Network Mode",
                        value = if (scanConfig.liveNetworkEnabled) "Passive DNS & TLS HTTP Fetch Enabled" else "Strict Local-Only (Network Disabled)",
                        badgeText = if (scanConfig.liveNetworkEnabled) "ONLINE" else "OFFLINE",
                        badgeColor = if (scanConfig.liveNetworkEnabled) palette.pass else palette.warn,
                    )
                    HorizontalDivider(color = palette.border, modifier = Modifier.padding(vertical = 8.dp))
                    ConfigStatRow(
                        label = "HTTP / DNS Timeout",
                        value = "${scanConfig.timeoutSeconds}s strict cap • Standard TLS verification",
                        badgeText = "${scanConfig.timeoutSeconds}S CAP",
                        badgeColor = palette.info,
                    )
                    HorizontalDivider(color = palette.border, modifier = Modifier.padding(vertical = 8.dp))
                    ConfigStatRow(
                        label = "Credential & Active Scan Guard",
                        value = "Passwords never stored/transmitted • No port scanning",
                        badgeText = "PASSIVE",
                        badgeColor = palette.primaryAccent,
                    )
                }
            }

            if (isWideScreen) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        ActivityTelemetryChart(
                            entries = activityHistory,
                            modifier = Modifier.weight(1f),
                        )
                        SecurityTipCard(
                            tip = currentTip,
                            onNextTip = onNextTip,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            } else {
                item {
                    ActivityTelemetryChart(entries = activityHistory)
                }
                item {
                    SecurityTipCard(
                        tip = currentTip,
                        onNextTip = onNextTip,
                    )
                }
            }

            item {
                // Quick Access Tools Overview
                SocTerminalCard(
                    terminalTag = "// TOOL_MODULES_QUICK_ACCESS",
                    accentColor = palette.secondaryAccent,
                ) {
                    Text(
                        text = "Cybersecurity Tool Suite",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select any diagnostic workbench or training track.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    val quickTools = listOf(
                        QuickToolSpec(
                            route = CyberRoute.PASSWORD,
                            title = "Password Analyzer",
                            subtitle = "Local entropy & pattern audit",
                            icon = Icons.Filled.Key,
                            accent = palette.primaryAccent,
                            tag = "quick_tool_password",
                        ),
                        QuickToolSpec(
                            route = CyberRoute.DOMAIN,
                            title = "Domain Analyzer",
                            subtitle = "URL parse, RFC checks & DNS",
                            icon = Icons.Filled.Language,
                            accent = palette.secondaryAccent,
                            tag = "quick_tool_domain",
                        ),
                        QuickToolSpec(
                            route = CyberRoute.HEADERS,
                            title = "Security Headers",
                            subtitle = "CSP, HSTS & clickjacking check",
                            icon = Icons.Filled.Shield,
                            accent = palette.warn,
                            tag = "quick_tool_headers",
                        ),
                        QuickToolSpec(
                            route = CyberRoute.IP_INFO,
                            title = "IP Information",
                            subtitle = "IPv4/IPv6 validator & RFC scope",
                            icon = Icons.Filled.Dns,
                            accent = palette.info,
                            tag = "quick_tool_ip",
                        ),
                        QuickToolSpec(
                            route = CyberRoute.LEARN,
                            title = "Learning Center",
                            subtitle = "Networking, Linux, OWASP Top 10",
                            icon = Icons.Filled.School,
                            accent = palette.primaryAccent,
                            tag = "quick_tool_learn",
                        ),
                        QuickToolSpec(
                            route = CyberRoute.SETTINGS,
                            title = "Settings & Scope",
                            subtitle = "Themes, offline mode & disclaimer",
                            icon = Icons.Outlined.Settings,
                            accent = palette.textSecondary,
                            tag = "quick_tool_settings",
                        ),
                    )

                    val columns = if (isWideScreen) 3 else 2
                    quickTools.chunked(columns).forEach { rowItems ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            rowItems.forEach { item ->
                                QuickAccessTile(
                                    spec = item,
                                    onClick = { onNavigate(item.route) },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            repeat(columns - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            item {
                // Recent Activity Section
                if (activityHistory.isEmpty()) {
                    EmptyTerminalCard(
                        title = "No Recent Diagnostic History",
                        subtitle = "Your executed domain, header, IP, and password audit summaries will appear here. No fake logs are pre-populated.",
                    )
                } else {
                    SocTerminalCard(
                        terminalTag = "// RECENT_ACTIVITY_HISTORY",
                        accentColor = palette.primaryAccent,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Recent Checks (${activityHistory.size})",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary,
                            )
                            OutlinedButton(
                                onClick = onClearHistory,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("clear_history_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteSweep,
                                    contentDescription = "Clear history",
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear")
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        activityHistory.take(8).forEachIndexed { index, entry ->
                            ActivityRow(entry = entry)
                            if (index < activityHistory.take(8).lastIndex) {
                                HorizontalDivider(
                                    color = palette.border,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun ConfigStatRow(
    label: String,
    value: String,
    badgeText: String,
    badgeColor: Color,
) {
    val palette = LocalCyberPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = palette.textPrimary,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        }
        StatusBadge(label = badgeText, color = badgeColor)
    }
}

@Composable
private fun SecurityTipCard(
    tip: SecurityTip,
    onNextTip: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    SocTerminalCard(
        modifier = modifier,
        terminalTag = "// SECURITY_BRIEF_${tip.category}",
        accentColor = palette.primaryAccent,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Lightbulb,
                    contentDescription = null,
                    tint = palette.primaryAccent,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Operational Tip",
                    style = MaterialTheme.typography.labelLarge,
                    color = palette.primaryAccent,
                )
            }
            IconButton(
                onClick = onNextTip,
                modifier = Modifier.testTag("next_security_tip_button"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Refresh,
                    contentDescription = "Next security tip",
                    tint = palette.secondaryAccent,
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = tip.title,
            style = MaterialTheme.typography.titleMedium,
            color = palette.textPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = tip.summary,
            style = MaterialTheme.typography.bodySmall,
            color = palette.textSecondary,
        )
    }
}

private data class QuickToolSpec(
    val route: CyberRoute,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val tag: String,
)

@Composable
private fun QuickAccessTile(
    spec: QuickToolSpec,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalCyberPalette.current
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(spec.tag),
        shape = RoundedCornerShape(12.dp),
        color = palette.surfaceElevated,
        border = BorderStroke(1.dp, palette.border),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(spec.accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = spec.icon,
                        contentDescription = spec.title,
                        tint = spec.accent,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = palette.textMuted,
                    modifier = Modifier.size(16.dp),
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = spec.title,
                style = MaterialTheme.typography.titleSmall,
                color = palette.textPrimary,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = spec.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ActivityRow(entry: ActivityLogEntry) {
    val palette = LocalCyberPalette.current
    val statusColor = when (entry.status) {
        ActivityStatus.PASS -> palette.pass
        ActivityStatus.WARN -> palette.warn
        ActivityStatus.INFO -> palette.info
        ActivityStatus.ERROR -> palette.fail
    }
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val timeText = formatter.format(Date(entry.timestampMillis))

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StatusBadge(label = entry.tool.displayName.uppercase(), color = statusColor)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = entry.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = entry.detail,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(
            text = timeText,
            style = MaterialTheme.typography.labelSmall,
            color = palette.textMuted,
        )
    }
}
