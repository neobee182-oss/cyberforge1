package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.data.UiState
import com.example.engine.IpAnalysisResult
import com.example.ui.components.EmptyTerminalCard
import com.example.ui.components.ErrorTerminalCard
import com.example.ui.components.KeyValueTerminalRow
import com.example.ui.components.QuickSampleChipRow
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette

@Composable
fun IpInfoScreen(
    ipInput: String,
    state: UiState<IpAnalysisResult>,
    onInputChange: (String) -> Unit,
    onAnalyze: (String?) -> Unit,
    onReset: () -> Unit,
) {
    val palette = LocalCyberPalette.current

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                SocTerminalCard(
                    terminalTag = "// IP_ADDRESS_VALIDATOR_&_CLASSIFIER",
                    accentColor = palette.info,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "IPv4 / IPv6 Information",
                            style = MaterialTheme.typography.headlineSmall,
                            color = palette.textPrimary,
                            modifier = Modifier.weight(1f),
                        )
                        StatusBadge(label = "NO SCANNING", color = palette.primaryAccent)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Validates IPv4 and IPv6 syntax locally, expands binary/hex format, and classifies RFC address scopes. Never pings, port-scans, or probes target hosts.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = ipInput,
                        onValueChange = onInputChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ip_input_field"),
                        label = { Text("IPv4 or IPv6 address (e.g. 192.168.1.10 or 2001:db8::1)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onAnalyze(null) }),
                        leadingIcon = { Icon(Icons.Filled.Dns, contentDescription = null) },
                        trailingIcon = {
                            if (ipInput.isNotEmpty()) {
                                IconButton(
                                    onClick = onReset,
                                    modifier = Modifier.testTag("ip_clear_button"),
                                ) {
                                    Icon(Icons.Outlined.Clear, contentDescription = "Clear IP input")
                                }
                            }
                        },
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    QuickSampleChipRow(
                        samples = listOf("192.168.1.10", "169.254.169.254", "2001:db8::1", "::1", "8.8.8.8"),
                        onSelect = { onAnalyze(it) },
                        tagPrefix = "ip",
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { onAnalyze(null) },
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("ip_analyze_button"),
                        ) {
                            Icon(Icons.Filled.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Validate & Classify")
                        }
                        if (state !is UiState.Idle) {
                            OutlinedButton(
                                onClick = onReset,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("ip_reset_button"),
                            ) {
                                Text("Reset")
                            }
                        }
                    }
                }
            }

            when (state) {
                UiState.Idle -> {
                    item {
                        EmptyTerminalCard(
                            icon = Icons.Filled.Dns,
                            title = "Enter an IPv4 or IPv6 Address",
                            subtitle = "Test private vs public RFC blocks, loopback addresses, CGNAT ranges, or IPv6 link-local & ULA prefixes offline.",
                        )
                    }
                }

                UiState.Loading -> Unit

                is UiState.Error -> {
                    item {
                        ErrorTerminalCard(message = state.message, hint = state.hint)
                    }
                }

                is UiState.Success -> {
                    val res = state.data
                    item {
                        SocTerminalCard(
                            terminalTag = "// RFC_CLASSIFICATION_REPORT",
                            accentColor = palette.primaryAccent,
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = res.canonicalAddress,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = palette.primaryAccent,
                                    modifier = Modifier.weight(1f),
                                )
                                StatusBadge(label = res.version.label, color = palette.info)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = palette.border)
                            KeyValueTerminalRow("RFC Classification", res.classification, palette.secondaryAccent)
                            KeyValueTerminalRow("Routing Scope", res.routingScope)
                            KeyValueTerminalRow("Standard Reference", res.rfcReference)
                            KeyValueTerminalRow(
                                if (res.version.name == "IPV4") "32-bit Binary Octets" else "128-bit Expanded Hex",
                                res.binaryOrHexRepresentation,
                            )
                            KeyValueTerminalRow("Common Subnet Context", res.subnetExample)
                        }
                    }

                    item {
                        SocTerminalCard(
                            terminalTag = "// EDUCATIONAL_CONTEXT",
                            accentColor = palette.secondaryAccent,
                        ) {
                            Text(
                                text = "Networking & Security Notes",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary,
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            res.educationalNotes.forEach { note ->
                                Text(
                                    text = "• $note",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    modifier = Modifier.padding(vertical = 3.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
