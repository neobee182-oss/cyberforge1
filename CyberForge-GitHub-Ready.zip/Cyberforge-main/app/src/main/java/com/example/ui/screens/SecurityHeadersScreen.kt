package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.UiState
import com.example.engine.HeaderStatus
import com.example.engine.SecurityHeaderAuditItem
import com.example.engine.SecurityHeadersAnalysisResult
import com.example.engine.SecurityHeadersAnalyzer
import com.example.ui.components.EmptyTerminalCard
import com.example.ui.components.ErrorTerminalCard
import com.example.ui.components.KeyValueTerminalRow
import com.example.ui.components.LoadingTerminalCard
import com.example.ui.components.QuickSampleChipRow
import com.example.ui.components.SocTerminalCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCyberPalette

@Composable
fun SecurityHeadersScreen(
    urlInput: String,
    state: UiState<SecurityHeadersAnalysisResult>,
    onUrlChange: (String) -> Unit,
    onInspect: (String?) -> Unit,
    onReset: () -> Unit,
) {
    val palette = LocalCyberPalette.current
    var showReferenceGuide by remember { mutableStateOf(state is UiState.Idle) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                SocTerminalCard(
                    terminalTag = "// HTTP_SECURITY_HEADERS_INSPECTOR",
                    accentColor = palette.warn,
                ) {
                    Text(
                        text = "Security Headers Analyzer",
                        style = MaterialTheme.typography.headlineSmall,
                        color = palette.textPrimary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Performs a standard passive HTTP HEAD/GET request with strict TLS verification to inspect CSP, HSTS, X-Frame-Options, and related defensive headers. Never bypasses security restrictions or fabricates missing data.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = onUrlChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("headers_url_input_field"),
                        label = { Text("Website URL (e.g. https://example.com)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Search,
                        ),
                        keyboardActions = KeyboardActions(onSearch = { onInspect(null) }),
                        leadingIcon = { Icon(Icons.Filled.Http, contentDescription = null) },
                        trailingIcon = {
                            if (urlInput.isNotEmpty()) {
                                IconButton(
                                    onClick = onReset,
                                    modifier = Modifier.testTag("headers_clear_button"),
                                ) {
                                    Icon(Icons.Outlined.Clear, contentDescription = "Clear URL")
                                }
                            }
                        },
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    QuickSampleChipRow(
                        samples = listOf("https://example.com", "https://developer.android.com", "https://owasp.org"),
                        onSelect = { onInspect(it) },
                        tagPrefix = "headers",
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { onInspect(null) },
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("headers_inspect_button"),
                        ) {
                            Icon(Icons.Filled.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inspect Live Headers")
                        }
                        if (state !is UiState.Idle) {
                            OutlinedButton(
                                onClick = onReset,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("headers_reset_button"),
                            ) {
                                Text("Reset")
                            }
                        }
                    }
                }
            }

            when (state) {
                UiState.Idle -> {
                    item {
                        EmptyTerminalCard(
                            icon = Icons.Filled.Shield,
                            title = "Ready to Inspect Response Headers",
                            subtitle = "Enter a URL you own or are authorized to inspect, or browse the Security Headers Reference Guide below.",
                        )
                    }
                }

                UiState.Loading -> {
                    item {
                        LoadingTerminalCard(message = "Fetching live HTTP response headers...")
                    }
                }

                is UiState.Error -> {
                    item {
                        ErrorTerminalCard(message = state.message, hint = state.hint)
                    }
                }

                is UiState.Success -> {
                    val res = state.data
                    item {
                        val postureColor = when {
                            res.presentCount >= 6 && res.isHttps -> palette.pass
                            res.presentCount >= 3 -> palette.warn
                            else -> palette.fail
                        }
                        SocTerminalCard(
                            terminalTag = "// RESPONSE_POSTURE_SUMMARY",
                            accentColor = postureColor,
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column {
                                    Text(
                                        text = "${res.presentCount} / ${res.totalChecked} Headers Present",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = postureColor,
                                    )
                                    Text(
                                        text = "HTTP ${res.httpStatusCode} • ${res.protocol}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = palette.textSecondary,
                                    )
                                }
                                StatusBadge(
                                    label = if (res.isHttps) "HTTPS" else "HTTP INSECURE",
                                    color = if (res.isHttps) palette.pass else palette.fail,
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            KeyValueTerminalRow("Final Inspected URL", res.finalUrl)
                            Text(
                                text = res.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                            )
                        }
                    }

                    items(res.headers, key = { it.headerName }) { header ->
                        HeaderAuditCard(header = header)
                    }
                }
            }

            item {
                SocTerminalCard(
                    terminalTag = "// SECURITY_HEADERS_REFERENCE_GUIDE",
                    accentColor = palette.secondaryAccent,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "Header Defense Reference (${SecurityHeadersAnalyzer.referenceGuide.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                        )
                        TextButton(
                            onClick = { showReferenceGuide = !showReferenceGuide },
                            modifier = Modifier.testTag("toggle_header_guide_button"),
                        ) {
                            Text(if (showReferenceGuide) "Hide" else "Show")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (showReferenceGuide) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                                contentDescription = null,
                            )
                        }
                    }
                    if (showReferenceGuide) {
                        Spacer(modifier = Modifier.height(8.dp))
                        SecurityHeadersAnalyzer.referenceGuide.forEachIndexed { idx, guide ->
                            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = guide.name,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = palette.secondaryAccent,
                                        modifier = Modifier.weight(1f),
                                    )
                                    StatusBadge(label = guide.importance, color = palette.info)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = guide.summary,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Recommended: ${guide.example}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.primaryAccent,
                                )
                            }
                            if (idx < SecurityHeadersAnalyzer.referenceGuide.lastIndex) {
                                HorizontalDivider(color = palette.border)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun HeaderAuditCard(header: SecurityHeaderAuditItem) {
    val palette = LocalCyberPalette.current
    val isPresent = header.status == HeaderStatus.PRESENT
    val statusColor = if (isPresent) palette.pass else palette.fail

    SocTerminalCard(accentColor = statusColor) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = header.headerName,
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.titleSmall,
                color = palette.textPrimary,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
            )
            StatusBadge(
                label = if (isPresent) "PRESENT" else "MISSING",
                color = statusColor,
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = header.purpose,
            style = MaterialTheme.typography.bodySmall,
            color = palette.textSecondary,
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (isPresent && !header.observedValue.isNullOrBlank()) {
            Text(
                text = "OBSERVED VALUE",
                style = MaterialTheme.typography.labelSmall,
                color = palette.textMuted,
            )
            Text(
                text = header.observedValue,
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.bodySmall,
                color = palette.primaryAccent,
            )
        } else {
            Text(
                text = "WHY THIS MATTERS: ${header.missingRisk}",
                style = MaterialTheme.typography.bodySmall,
                color = palette.warn,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "RECOMMENDED: ${header.recommendedValue}",
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelMedium,
                color = palette.secondaryAccent,
            )
        }
    }
}
