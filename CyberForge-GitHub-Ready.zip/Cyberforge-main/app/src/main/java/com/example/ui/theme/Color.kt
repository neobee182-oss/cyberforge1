package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian SOC Surfaces
val ObsidianBlack = Color(0xFF05080A)
val TerminalSurface = Color(0xFF0B1115)
val TerminalElevated = Color(0xFF111A20)
val TerminalCardAlt = Color(0xFF152028)
val TerminalBorder = Color(0xFF1E2E38)
val TerminalBorderBright = Color(0xFF2B4352)

// Text Hierarchy
val TextPrimary = Color(0xFFEAF4F8)
val TextSecondary = Color(0xFF9FB4C0)
val TextMuted = Color(0xFF647B88)

// Accent Palettes
val NeonGreen = Color(0xFF00FF88)
val NeonGreenDim = Color(0xFF00C96B)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDim = Color(0xFF00B2CC)
val SkyPulse = Color(0xFF38BDF8)
val TacticalAmber = Color(0xFFFFB300)
val PlasmaViolet = Color(0xFF8B5CF6)

// Semantic Status Tokens
val StatusPass = Color(0xFF00FF88)
val StatusInfo = Color(0xFF00E5FF)
val StatusWarn = Color(0xFFFFB300)
val StatusFail = Color(0xFFFF4D6D)
val StatusUnavailable = Color(0xFF647B88)
